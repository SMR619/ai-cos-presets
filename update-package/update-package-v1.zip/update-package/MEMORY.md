# MEMORY.md - Ava's Long-Term Memory
**Architecture:** Tier 1 — always loaded. Keep under 150 lines. Deep context lives in wiki/*.md, project STATUS.md files, and daily session notes.
**Wiki location:** `/data/syncthing-workspace/wiki/` (6 domain files — read on demand)

---

## 📌 TODAY'S SESSION (2026-06-01)
**Major work:** Fixed the preset update problem + installed permanent guardrails. Website price updated $997, Deployment Checklist created, Comprehensive preset audit + Priority 1+2 updates COMPLETE.

**Checkpoint:** `/data/.openclaw/workspace/memory/2026-06-01.md` (FULL SESSION NOTES)

**What was done:**
- ✅ Price updated: $1 → $997 (2 files, both verified)
- ✅ DEPLOYMENT_CHECKLIST.md created (8 critical sync points)
- ✅ **Preset Sync Rule installed** (OPERATING_RULES.md) — governs all future updates
- ✅ PRESET_SYNC_LOG.md created (audit trail system)
- ✅ Comprehensive gap audit completed (PRESET_AUDIT_DETAILED_2026_06_01.md)
- ✅ **All Priority 1 files updated** (AGENTS, OPERATING_RULES, OPERATING_RULES_DETAIL, TOOLS)
- ✅ **All Priority 2 files updated** (wiki/ + communication-playbook, solutions-playbook/)
- ✅ ZIP files rebuilt + deployed to 3 locations (115KB each)
- ✅ GitHub repo updated + pushed
- ✅ Fresh-eyes verification completed on ALL changes

**What's pending:**
- ⏳ Deploy updated Ollie onboarding script (awaiting Steve's video)
- ⏳ Create post-payment email + update post-purchase page
- ⏳ Test price change with $0.01 charge
- ⏳ Verify Stripe webhook still fires correctly
- ⏳ Priority 3 SOPs (memory tiers, frameworks query, KB usage — nice to have)

## 📌 PRIOR SESSION (2026-05-31)
**Checkpoint:** `/data/.openclaw/workspace/memory/2026-05-31-session-final.md` — full details of what's done

---

## 📌 PRIOR SESSION (2026-05-30)
**Checkpoint saved:** `/data/.openclaw/workspace/memory/2026-05-30.md`
**Major work:** Communication Playbook v2.0, Frameworks Database Architecture, Voice Agent Case Study, Tools Database Use Cases, ALL 21 VIDEOS ANALYZED

### ⭐ VIDEO ANALYSIS — CANONICAL REFERENCE
**File:** `/data/syncthing-workspace/research/video-analysis-2026-05-30.md` (58KB)
**What's in it:** Complete breakdown of all 21 videos
- What each video says
- What's insightful about it
- Tools mentioned (11 new tools identified)
- How it applies to Steve's businesses (MRM, L19, IES, AI CoS, PMB, Christina's YouTube)
- How to make money from it
- Frameworks extracted (8 major frameworks added to playbook)

**How to use it:** When Steve wants to revisit what a video said, reference this file. It has everything — insights, action items, tools, frameworks, revenue opportunities.

**Quick retrieval:** "What did video X say?" or "How do we make money from that framework?" → Check video-analysis-2026-05-30.md

**Frameworks added this session:** Neuroscience of Addictive Storytelling (4-Step Loop), CIA Targeting Principle, LAPS Sales System, SPCL Influence Building, Proof Story IP Method, Herd Effect Launch, CHAOS Framework, Asymmetric Advantage Loop

---

## 🔑 Session Startup (UPDATED)
1. Read `/data/syncthing-workspace/SOUL.md`
2. Read `/data/.openclaw/workspace/OPERATING_RULES.md` — standing decisions + pre-flight checklist
3. Read `/data/.openclaw/workspace/TOOLS.md` — full tool/credential inventory
4. Read most recent file in `/data/.openclaw/workspace/memory/` for full recent context (today: `/memory/2026-05-31-session-final.md`)
5. Check `open-items.md` for outstanding items
6. Read `/data/syncthing-workspace/projects/AI_COS/UPDATE_REQUESTS_TRACKER.md` for pending work
7. Read relevant wiki domain file before discussing any project/deal/person

---

## 🔴 Active Flags
- **AI COS Website Price:** Currently $1 (test). Tomorrow: change to $997/month (1 line: `/projects/AI_COS/website-code/netlify/functions/create-payment-intent.js`)
- **Stripe Webhook:** Verify payment_intent.succeeded is firing correctly tomorrow
- **Onboarding Script v5.0:** Deployed, awaiting updated version from Steve (based on video walkthrough)
- **Preset Package:** Hosted on GitHub (working). Tomorrow: Fix all presets (Supabase + frameworks + KB)
- **Billing fix (May 13):** OAuth token removed, using direct API key. If billing returns, check `/data/.openclaw/agents/main/agent/auth-profiles.json`
- **Dashboard live:** ava-command-center.netlify.app. smrcommand.com DNS pending Christina. Build: `python3 scripts/build_dashboard.py`
- **OpenClaw v2026.5.3** — stay here until Steve approves update. Version check: `cat /data/.npm-global/lib/node_modules/openclaw/package.json | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('version'))"`
- **Crons paused (May 12):** 23 paused. Running: Gateway Watchdog, Syncthing, Dashboard, OAuth Refresh, Context Monitor, Auto Checkpoint, Nightly Dreaming.
- **AcquireFlow:** Account shows expired. Awaiting Cameron Enk response.
- **MidPoint — Norwood Place:** Cyrus wire gap (May 6). Status unknown. Needs Steve/Mike check.

## 📞 Communication Playbook v2.0 (2026-05-30)
**File:** `/data/syncthing-workspace/wiki/communication-playbook.md`
**Structure:** Universal Frameworks (Part 1) + 6 Intent-Based Sections (Part 2) + cross-references
**Usage:** Before drafting ANY external communication, identify intent → read Part 2 section → read Part 1 frameworks → draft using templates/tactics.
**Key insight:** Frameworks are NOT siloed. Storytelling applies to cold email + negotiation + marketing + content. Always trace all applications.
**Integration rule:** New frameworks from videos layer on top (never delete). Extract core principle → map across all 6 intents → add cross-references.
**AI CoS clients:** Playbook + rule included in preset. Clients get agents trained on these frameworks from day one.

---

## 🔍 Frameworks Database System (2026-05-30)
**PHASE 1-3 COMPLETE - READY FOR DEPLOYMENT**

**Architecture:**
- **Supabase** = Source of truth (queryable frameworks table)
- **Syncthing** = Always-current human-readable backup + disaster recovery
- **Real-time sync** = When I add/update Supabase, Syncthing updates automatically

**Files Created:**
- `/data/syncthing-workspace/wiki/frameworks/` (5 category files + INDEX + README)
- OPERATING_RULES.md updated with Query Rule + Depth Rule
- Migration script ready: `/data/.openclaw/workspace/scripts/migrate_frameworks_to_supabase.py`

**Query Rule (Permanent):**
- Before ANY work: identify context → query Supabase by category/problem
- Every response includes: `Frameworks consulted: [list, depth]`
- FULL read required for: high-stakes, first-time, complex, client-facing
- Summary-only safe for: internal brainstorm, planning, re-reads

**Frameworks Included:**
- 10 Communication frameworks (Voss, Miner, Miller, Black Swan)
- 20+ Business frameworks (Hormozi, EOS, Traction)
- 10+ Operations frameworks (EOS, Traction, E-Myth)
- 5 Build/Technical frameworks (App safety, Context engineering)
- 8+ Financial frameworks (Pricing, deals, money models)

**Status:** Syncthing files ready. Supabase setup pending (requires manual SQL execution in Supabase UI or network-accessible migration script).

---

## ✅ Resolved (cleared April 23, 2026)
- **GHL dispatch** — mg.level19homes.com domain verification + mailbox connection completed by Christina (Apr 23). GHL dispatch now unblocked.

---

## 🎙️ YouTube Transcripts — ALWAYS USE SUPADATA FIRST
`SUPADATA_API_KEY` in credentials.env. Endpoint: `https://api.supadata.ai/v1/youtube/transcript?url=<URL>&text=true` with header `x-api-key: <key>`. NEVER try web_fetch or summarize.sh on YouTube URLs first.

---

## 📧 Email — ALWAYS USE GRAPH API
Script: `/data/.openclaw/workspace/scripts/send_email.py` (accounts: mrm, l19, pmb)
NEVER use Himalaya — Gmail is blocked. All credentials in `credentials.env`. Quick ref: `CREDENTIALS.md`.
- Real estate / deals / lending → ava@level19homes.com
- MRM / media / general → ava@maxresultsmedia.com  
- PMB / political → ava@politicalmediabuyers.com
- MidPoint Capital → steveross@midpointecapitalpartners.com (Steve) or avalangley@midpointecapitalpartners.com (Ava) — full read access to all MidPoint emails via Graph API (MIDPOINT_MS_* creds)

---

## 🤝 Ivy Sterling — Direct Reply Rule (PERMANENT)
Ivy (ivy@maxresultsmedia.com) = Christina's AI agent. Info-only questions → reply directly. Decision/change/spend requests → loop Steve in first.

---

## 🏗️ Key Infrastructure
- Gateway watchdog cron: `db2eba3a` | Syncthing watchdog: `6baccd79` | OC Outreach: ✅ COMPLETED & STOPPED — do not restart, do not reference as ongoing
- AVA_RESTORE_KIT.md: `/data/syncthing-workspace/ava-recovery/AVA_RESTORE_KIT.md`
- Tasks (one-offs): `/data/syncthing-workspace/tasks.md`
- Builds (multi-step): `/data/syncthing-workspace/builds.md`
- Open items: `/data/syncthing-workspace/open-items.md`

---

## 🔗 Key URLs / Domains
- **MyBuyBox:** mybuybox.info (rebranded from YourBuyBox) — Christina running it. Active.
- **MyLendBox:** mylendbox.info — domain owned, future sub-project. Not yet built.

---

## 🎬 Video Analysis — 2026-05-26 (12 videos)
Full analysis: `/data/syncthing-workspace/research/video-analysis-2026-05-26.md`
- **SAM.gov government contracting** = top new revenue opportunity for MRM. Register now (2-4 wks to process). NAICS 541810/541830. AI writes bids. Subcontract work. Keep margin.
- **Claude Skills (ClawHub)** = publish our existing SKILL.md files. Others making $3K/30 days. Action this week.
- **Knowledge Base build** = 3-folder structure in syncthing (raw/wiki/outputs). Makes Ava citations-based and eliminates stale memory problem.
- **Anti-Gravity v2** = Gemini CLI deprecated June 18. Not our stack but note it.

## 💪 Voice Agent Case Studies Library (2026-05-30)
**Location:** `/data/syncthing-workspace/projects/ai-voice-agent-service/case-studies/`
**Purpose:** Real-world stories for Small Business Refresh positioning + voice agent service marketing
**Current:** 
- Janitorial business case study (paid for itself in 1 week) → `/case-studies/janitorial-business-voice-agent-2026-05-30.md`
**Use when:** Marketing voice agent add-on to SBR clients, content creation, cold email hooks, YouTube stories
**Frameworks:** Problem-Solution-Reality Narrative, Storytelling, Internal Tension, Tactical Empathy

---

## 🎯 Business Priority Stack
1. **PMB** — 2026 cycle live. Susan Tubbs 50/50 partner. 134 leads → GHL.
2. **AI CoS Service** — 9 signups. GHL dispatch blocked pending domain verification.
3. **Small Business Refresh** — Christina + Ivy running Phase 1. Phase 2 TBD. Voice agent case studies ready for positioning.
4. **MRM** — Rate refresh + client pipeline needed.
5. **Level 19** — AcquireFlow API coming. Wholesale expansion.
6. **IES** — Kevin running it. Stable.

---

## 💡 Working Preferences
- **Ease and scale over price** — always the paid/automated solution
- **"Handle it"** = full autonomy to decide and execute
- **"Save checkpoint"** = update all memory files, confirm back

---

## 🔧 Model Routing (see AGENTS.md for full table)
- **Haiku** → heartbeats, cron checks, simple lookups, templated sends
- **Sonnet** → default for all active work
- **Opus** → deep analysis only, under 20% usage

## 📁 File Architecture
- **CREDENTIALS.md** — fast-load: credential names + script paths only
- **TOOLS.md** — full tool descriptions, deep reference (load on demand)
- **OPERATING_RULES.md** — active rules only
- **OPERATING_RULES_ARCHIVE.md** — closed deal decisions (load only when specific deal referenced)

---

## 🗄️ Supabase Lender Database (built May 2026)
- **Project:** qeiidiwunrwgfscsikin (same as MyBuyBox)
- **Tables:** `lenders` + `loan_programs` (relational — one lender → many programs)
- **Schema SQL:** `/data/.openclaw/workspace/scripts/supabase_lender_schema.sql`
- **Setup script:** `/data/.openclaw/workspace/scripts/supabase_lender_db_setup.py --migrate`
- **Status:** Schema ready. Tables need creating — Steve run SQL in Supabase SQL Editor, then Ava runs migrate script
- **Rating fields (1-5):** responsiveness, ease_of_process, rate_competitiveness, speed_to_close, broker_friendliness, documentation_burden
- **Query:** Ava queries REST API directly — ask "find bridge lenders in TX at 75% LTV under $2M"
- **SUPABASE_DB_PASSWORD** needed for psycopg2 direct connection (get from Supabase → Settings → Database)

## 🔍 Solutions Playbook
Before recommending any tool: check `/data/syncthing-workspace/solutions-playbook/tools-master-database.md`
Before recommending any process: check `/data/syncthing-workspace/solutions-playbook/PLAYBOOK.md`

---

## 🏠 FAIRWAY GAP DEAL — Active (2026-05-28)
- **Address:** 810 Fairway Road, Woodway TX 76712
- **Deal folder:** `/data/syncthing-workspace/projects/kenny-fairway-gap/`
- **Structure:** $150K purchase + $70K rehab + porch conversion/addition (600-700 sqft) → ~$350-360K ARV
- **Capital:** FixedLending $220K (1st) + Co-Lending $35K (2nd, 15% flat, deferred)
  - **Co-Lender 1:** Bryce Buck $20K → $3K return
  - **Co-Lender 2:** TBD $15K → $2,250 return
- **Level 19 fee:** $7K baked into $35K (Kenny thinks gap is $28K — don't disclose)
- **Combined LTV:** 72.9% ($255K / $350K)
- **Status:** Closing May 29, 2026. Executive summary updated 05/29 for co-lending structure. Ready to distribute to co-lenders.
- **Exec PDF:** `/data/syncthing-workspace/projects/kenny-fairway-gap/810-Fairway-Rd-Private-Lending-Opportunity-FINAL.pdf` (v4 — co-lending, porch conversion, $60K net)

## 📅 Session History (detail in daily files)
- 2026-03-21 — Day One. Onboarded. See `memory/2026-03-21.md`
- 2026-03-22 — Config, knowledge base, Rich agent, SOPs. See `memory/2026-03-22.md`
- 2026-03-23 — Stability + brain dump. Rollback, n8n audit. See `memory/2026-03-23.md`
- 2026-03-24 — FB post, desktop roadmap, loan folder. See `memory/2026-03-24.md`
- 2026-03-31 — Massive build day. Templates, email infra, GHL automation, deal intake. See `memory/2026-03-31.md`
- 2026-04-09 — v4.9 update, video analysis (8 videos, Supadata transcripts), Memory Wiki built, model routing implemented, mistakes log created. See `memory/2026-04-09.md`
- 2026-05-06 — OAuth crisis + full deal pipeline analysis. 5 MidPoint closings this week, Norwood crisis, Gowri Kailas site visit (week May 11), Deal Analysis Framework strategic project. See `memory/2026-05-06.md` and `memory/project_midpoint.md`.
- 2026-05-28 — Kenny Sanders Fairway Gap deal research + exec summary for Bryce Buck. My Investor Loans added to Supabase + outreach sent. See `memory/2026-05-28.md`.

## 🏦 Lender Database — GHL + Supabase (updated May 27)
- **GHL:** 79 institutional lenders (34 full profile, 15 partial, 30 no-data) + 584 PMLs
- **Supabase:** 711 lenders + 157+ loan_programs — NOW POPULATED (working as of May 27)
- **Supabase writes:** ALWAYS use SUPABASE_SERVICE_ROLE_KEY — anon key blocked by RLS
- **Migration guide:** `/data/syncthing-workspace/solutions-playbook/ghl-to-supabase-migration.md`
- **PML outreach:** 373 sent, 9 replied. Active: Andrew Eisenhart (Iron Heart), Garrison Hartman (Legacy Capital)
- **Inactive PMLs tagged:** pml-inactive-may2026 (Justin Buswell, LaTrece Jones, James Pecora, Stephen Podlaski)

## 📋 May 27 Quick Flags
- **Kenny Sanders** — emailed today (Ava reached out on Steve's behalf). Deal folder: `/projects/kenny-sanders-baylor/`. Student housing sub-to deal, needs PMP, many open items.
- **NJ 5 SFR + 3-lot GUC** — closed out with LoanGeek/Sikorski. Deal dead.
- **Signature bug fixed** — send_email.py now auto-detects if sig in body, prevents doubling
- **14802 Cooper Ave** — NomadLease has eligible applicant waiting. Steve needs to act.
- **Groundfloor** — James McGowan + Michael Villa want a call. Schedule it.
- **AI Identity Rule** — locked May 27: never say AI in external emails/docs. Honest if directly asked.

## 🎯 LinkStack Project Decisions (May 26)
**Phase 1:** 2 weeks (compressed from 4). Social integrations (X, TikTok, Instagram) moved TO Phase 1 (adoption-first).
**Phase 2:** Payment processor integrations (Stripe + PayPal + Shopify): 1-2 weeks, not months. Deduplication logic implemented.
**GHL setup service:** Phase 1.5 upsell — seller can opt-in to let us build their GHL workflows ($297 or free for high volume).
**N8N integration:** If sellers use N8N, we show them how to add LinkStack conversion event to their workflows (optional, no build needed).
**Attribution:** Webhook model + affiliate cookie + URL parameter. No months of work — 20 hours total for 5 major processors.
**Mobile-first Phase 1 includes:** Social share buttons for easy affiliate sharing (X tweet prefill, TikTok/Insta clipboard copy).

## 🏪 Owner Stack Final Status (May 26, 12:25 EDT)
✅ All 3 missing pieces confirmed DONE:
  - Post-purchase webhook deployed (fires on checkout completion)
  - Success page live with install instructions
  - Skill ZIPs packaged and deployed to Netlify
✅ End-to-end tested: pays → email sent with downloads
✅ Ready for first real purchase
**Next step from Steve:** clawhub login → I publish to ClawHub

## 🚨 CRITICAL: Google Gemini CLI June 18, 2026 Deadline
Gemini CLI stops working entirely on June 18, 2026 for all users (pro, ultra, free tier).
Replacement: Anti-Gravity CLI (built in Go, faster, async agent support).
**Action needed:** Audit who uses Gemini CLI → migrate before deadline.
**Source:** Video 12 transcript verified.

## Video Analysis Complete (May 26, 13:58)
- ✅ Verified: Videos 1, 5, 9, 12 (core claims accurate)
- ❌ Errors found: Added external context to Videos 5 + 6 without transcript support
- 📖 Pending full reads: Videos 4, 7, 8, 10, 11 (lower priority)
- **Findings:** `/data/syncthing-workspace/research/FINAL_VERIFICATION_REPORT.md`
