---
summary: "Pre-flight checklist and standing decisions for [AGENT_NAME]"
read_when:
  - Every session, after MEMORY.md
  - Before flagging anything as blocked or unknown
  - Before asking the owner for any credential, tool, or access
---

# OPERATING_RULES.md — [AGENT_NAME] Pre-Flight Rules

**Read this every session after MEMORY.md. Check it before surfacing anything to the owner.**

---

## 🔑 Pre-Flight Checklist

Before flagging ANYTHING as "unknown," "blocked," or asking the owner for credentials/access:

1. Check `TOOLS.md` — is it already there?
2. Check `credentials.env` — does the credential exist?
3. Check `WHAT_IS_BUILT.md` — was it already built?
4. Check the relevant project `STATUS.md` — was it already decided?
5. Check the most recent `memory/YYYY-MM-DD.md` — was it resolved recently?

Only ask the owner if all five checks come up empty.

---

## ⚡ Deferred Fix Rule

If you identify a fix, improvement, or correction during a session:
- **Under 5 minutes to fix → do it NOW.** Not later. Not a note. Not a reminder. Fix it.
- Only defer work that genuinely requires the owner's input or is too complex to complete in the current session.
- Never leave a known problem sitting when you have the access and ability to solve it.

---

## 📋 Open Items Discipline

`open-items.md` is for **the owner's decisions only.** Three categories:
1. **Today** — needs action from the owner today
2. **Decisions Needed** — owner must choose before you can proceed
3. **Waiting on External** — table only, no text blocks

**Never add to open-items.md:**
- Things the agent is monitoring (that's the agent's job, not the owner's)
- Things already resolved — remove them in the same session
- FYI items — if the owner doesn't need to decide, it doesn't belong there

**Never re-surface a resolved item.** Mark it `✅ RESOLVED [date]` and remove it that session.

---

## ✅ Standing Decisions

*(Update this section whenever the owner makes a decision that should never be re-asked.)*

| Decision | Status | Date |
|---|---|---|
| *Add decisions here as they're made* | | |

**Format to add a new entry:**
`| What was decided | ✅ CLOSED | YYYY-MM-DD |`

---

## 📋 Built Asset Index

*(Pointer to WHAT_IS_BUILT.md — before offering to build anything, check there first.)*

**Full inventory:** See `WHAT_IS_BUILT.md`

Key assets (update as built):
- [ ] Email send script
- [ ] Deal intake template
- [ ] Lender/client outreach template
- [ ] Email signatures
- [ ] GHL setup

---

## 📂 Open Items Discipline

Only items genuinely waiting on the owner belong in `open-items.md`.

**Never add to open-items.md:**
- Items listed as ✅ CLOSED in Standing Decisions above
- Tool/credential questions (check TOOLS.md first)
- Items the owner already answered in recent session notes

**Always do in the same session an item is resolved:**
1. Mark it `✅ RESOLVED [date] — [one line summary]` in open-items.md
2. Add it to Standing Decisions above so crons don't re-surface it

---

## 🔧 Cron Context Rule

Cron jobs and checkpoints must read this file BEFORE evaluating open-items.md.
Never re-surface an item marked ✅ CLOSED here.

---

*Last updated: [DATE] | Built by [AGENT_NAME]*
