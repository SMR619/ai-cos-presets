---
summary: "Inventory of all tools and credentials [AGENT_NAME] has access to"
read_when:
  - Every session, after OPERATING_RULES.md
  - Before asking the owner for any credential or tool access
  - Before flagging anything as "blocked" due to missing access
---

# TOOLS.md — [AGENT_NAME] Tool & Credential Inventory

**Check this BEFORE asking the owner for any credential, tool, or access.**
If it's not here after checking, THEN ask.

---

## How to Use This File

- Each section = one service/tool
- `Credentials` = environment variable names (actual values are in `credentials.env`)
- `Status` = ✅ Active / 🔧 Setup Needed / ❌ Not Connected
- Update this file immediately whenever a new tool is connected

---

## 📧 Email

### [EMAIL_PROVIDER] — [ACCOUNT_EMAIL]
- **Status:** 🔧 Setup Needed
- **Access:** [Microsoft Graph API / Gmail API / IMAP-SMTP]
- **Credentials:** See `credentials.env` → [ENV_VAR_NAMES]
- **Use for:** Sending and monitoring email on behalf of [OWNER_NAME]
- **Notes:** Set up during onboarding via `sops/sop-email-infrastructure.md`

---

## 📊 CRM

### GoHighLevel — [LOCATION_NAME]
- **Status:** 🔧 Setup Needed
- **Access:** REST API
- **Credentials:** See `credentials.env` → GHL_API_KEY, GHL_LOCATION_ID
- **Use for:** Creating/updating contacts, deals, pipelines, sending emails via GHL
- **Notes:** Set up during onboarding via `sops/sop-ghl-email-sync.md`

---

## 🗂️ File Sync

### Syncthing
- **Status:** 🔧 Setup Needed
- **Access:** Local process on VPS
- **Shared workspace:** `/data/syncthing-workspace/`
- **Use for:** Syncing files between VPS and owner's computer in real time
- **Notes:** Start with: `nohup syncthing serve --no-browser >> /data/.openclaw/workspace/syncthing.log 2>&1 &`

---

## 🤖 AI / Research

### Anthropic API (Claude)
- **Status:** ✅ Active (built into OpenClaw)
- **Credentials:** Managed by OpenClaw — no separate setup needed
- **Use for:** All reasoning, drafting, analysis

### OpenAI API
- **Status:** 🔧 Setup Needed (if needed)
- **Credentials:** See `credentials.env` → OPENAI_API_KEY
- **Use for:** Whisper transcription, GPT-4 tasks if needed

---

## 🔧 Automation

### n8n
- **Status:** 🔧 Setup Needed
- **Access:** REST API
- **Credentials:** See `credentials.env` → N8N_API_KEY, N8N_BASE_URL
- **Use for:** Workflow automation, connecting services

---

## 📦 Version Control

### GitHub
- **Status:** 🔧 Setup Needed
- **Access:** Personal Access Token
- **Credentials:** See `credentials.env` → GITHUB_TOKEN
- **Use for:** Backing up workspace files, version history

---

## ➕ Adding New Tools

When a new tool is connected:
1. Add a section here with status ✅ Active
2. Add env var names to `credentials.env` (values only, never in this file)
3. Update `WHAT_IS_BUILT.md` if any automation was built for it

---

*Last updated: [DATE] | Maintained by [AGENT_NAME]*
