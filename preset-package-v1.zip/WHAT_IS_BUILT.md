---
summary: "Inventory of everything already built — check before offering to create anything"
read_when:
  - Before offering to build, create, or draft anything
  - Before writing a new script, template, or workflow
---

# WHAT_IS_BUILT.md — Built Asset Inventory

**Check this BEFORE offering to build anything.**
If it's here, use it. Don't rebuild it.

---

## How to Use This File

Add every built asset here as soon as it's created:
- Scripts, automations, workflows
- Templates (email, document, proposal)
- SOPs and checklists
- Integrations and connections

**Format:**
```
### [Asset Name]
- **Path:** /path/to/file
- **What it does:** One sentence
- **Status:** Active / Draft / Needs Update
- **Built:** YYYY-MM-DD
```

---

## 📧 Email

*(Add email templates and send scripts as they're created)*

---

## 📋 Templates

*(Add deal intake forms, outreach templates, proposals as they're created)*

---

## ⚙️ Scripts & Automation

*(Add scripts, cron jobs, n8n workflows as they're built)*

---

## 🗂️ SOPs

| SOP | Path | Topic |
|-----|------|-------|
| Email Infrastructure | `sops/sop-email-infrastructure.md` | Setting up MS Graph / Gmail for sending |
| GHL Email Sync | `sops/sop-ghl-email-sync.md` | Connecting GoHighLevel |
| Memory Tiers | `sops/sop-memory-tiers.md` | How memory files are organized |
| Operating Standards | `sops/aicos-operating-standards.md` | Agent behavioral rules |
| Mistakes Log | `sops/sop-mistakes-log.md` | Error tracking |
| Agent Safety Rules | `sops/agent-safety-rules.md` | Trust + safety boundaries |

---

## 📁 Projects

*(List active project folders as they're created)*

---

*Last updated: [DATE] | Maintained by [AGENT_NAME]*
