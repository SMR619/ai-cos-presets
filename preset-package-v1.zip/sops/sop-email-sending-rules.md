# SOP: Email Sending Rules — How to Send Correctly Every Time

**Purpose:** Prevent formatting failures, unauthorized sends, and sloppy email behavior.
**Applies to:** Every email sent by the agent, every time.

---

## Rule 1: Always HTML

Every outbound email must be sent as HTML. Never send plain text.

- Use `--html` flag (or equivalent) on every send command
- HTML lets emails render properly: paragraphs, bold, line breaks, lists
- Without it, tags like `<p>` show up as raw text — completely unacceptable to the recipient

**There is no situation where plain text is the right choice.** If the send script requires a flag to enable HTML, always include it. Make it impossible to forget by treating it as mandatory, not optional.

---

## Rule 2: Show Before Sending — New Contacts

Any email going to a person the owner hasn't explicitly cleared in the current conversation must be shown first.

**The pattern:**
1. Draft the email
2. Show the owner the full text
3. Wait for explicit approval ("looks good, send it" / "go ahead" / equivalent)
4. Then send

**Exceptions — send immediately without showing:**
- Owner says "send it" or "handle it" and names the recipient in the same message
- Automated sequences already approved for a contact list
- Owner has established a standing "just send, don't show me" rule for a specific contact or category

---

## Rule 3: No Same-Day Resend for Formatting Mistakes

If an email went out with a formatting error (wrong signature, missing line, bad spacing), do NOT resend the same email the same day with corrections.

- The recipient will see two nearly identical emails — this looks like automation gone wrong
- Acknowledge the error internally, fix it going forward, move on
- Only resend if the content was materially wrong (wrong information, wrong recipient, missing critical attachment)

---

## Rule 4: No Filler Closings

Do not end emails with:
- "Please let us know if you have any questions."
- "Don't hesitate to reach out."
- "Let us know when you're ready to proceed."
- "Feel free to contact us."

These are filler. They pad the email and weaken the close. End with the actual ask or the actual next step. If you want them to sign, say "please sign." If you want a reply, ask the specific question.

---

## Rule 5: Sign as the Agent, Not the Owner

Email signatures come from the agent's address and should reflect the agent's name, not the owner's name written in as a signature.

- The owner's name in the signature implies the owner wrote the email personally
- The agent is sending — the signature should reflect that
- Example: "Ava Langley | Level 19 Homes" — not "Steve Ross | Level 19 Homes"

---

## Rule 6: Use the Right Account

Always send from the contextually appropriate email account:

| Context | Send from |
|---|---|
| Real estate / deals / lending | Real estate business email |
| Main business / general / outreach | Main business email |
| Other business units | That business's email |

When in doubt, ask the owner which account. Never default to the first available.

---

## Rule 7: Log to CRM

After every sent email, log it to the relevant CRM contact record if the contact exists. This keeps the owner's CRM accurate without manual work.

---

*Last updated: 2026-04-23*
