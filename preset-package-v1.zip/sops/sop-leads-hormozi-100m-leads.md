# SOP: $100M Leads — Getting Strangers to Want to Buy Your Stuff
**Source:** $100M Leads by Alex Hormozi  
**Processed:** 2026-03-23  
**Applies To:** [BUSINESS NAME] (adapt examples to your specific industry and lead sources)

---

## CORE FRAMEWORK SUMMARY

**The fundamental problem:** Potential customers can't buy from you if they don't know you exist. Advertising is the process of making known. You can only grow a business in two ways: (1) get more customers, (2) make them worth more. This book solves #1.

**The only two inputs to business growth:**
1. More Leads → More Customers
2. Better Leads → Higher-Value Customers
3. Cheaper Leads → More Profit Per Customer
4. Reliable Leads → Predictable Revenue

**Core Definition:** An **engaged lead** is a person who has shown interest in what you sell and can be contacted. Engaged leads (not just raw contacts) are the true output of advertising.

**Bottom line:** Double your engaged leads → Double your business. All else being equal.

**Hormozi's track record:** 36:1 lifetime ROAS. $250M+ annual revenue across portfolio. 20,000+ leads per day. Built entirely on the methods in this book.

---

## KEY PRINCIPLES

1. **You aren't getting enough leads because you aren't advertising enough.** Period. Full stop.

2. **The Content, not the content.** The individual piece of content isn't the compounding asset — the **audience** is. Build audience. The audience feeds you forever.

3. **Volume beats tactics every time.** Doing the right thing 1/1500th of the required volume fails. You must do MORE than you think is enough.

4. **Open to Goal > Rule of 100.** Don't commit to a number of actions. Commit to outcomes and do whatever it takes to hit them.

5. **Lead magnets first.** Often you'll get 3x more leads by advertising a free valuable offer first rather than going straight to the sale.

6. **The audience is the asset.** Build once, monetize forever. Content that disappears is fine — the audience it builds does not.

7. **Every lead is a potential lead getter.** Customers can refer. Employees can recruit. Agencies can teach. Affiliates can sell. Build systems for all four.

8. **Advertising works. Only the efficiency is variable.** Stop asking "does this work?" Start asking "how well can I make it work?"

---

## SECTION I: UNDERSTANDING ADVERTISING

### Lead Magnet Framework

A **lead magnet** is a complete solution to a narrow problem that:
- Is free or low cost (to maximize engagement)
- Reveals a larger problem that your core offer solves
- Provides enough value you could charge for it

**The Problem-Solution Cycle:**
Every solution reveals a new problem. Pick the narrow problem that, when solved, reveals the larger problem your core offer addresses.

*Example: Help homeowners understand what their home is worth (narrow) → reveals they still need to sell (core offer).*

**Apply the Grand Slam Offer framework to free stuff.** Make your lead magnet so insanely good that people feel stupid saying no. The business that provides the most value wins.

### 7 Steps to Creating an Effective Lead Magnet

1. **Figure out the problem** to solve and who to solve it for
2. **Figure out how to solve it** (3 types: reveal problem, sample/trial, free tool)
3. **Figure out how to deliver it** (written, audio, video, in-person)
4. **Test what to name it** (use MAGIC formula from $100M Offers)
5. **Make it easy to consume** (simple, short, actionable)
6. **Make it darn good** (over-deliver — builds trust for the core offer)
7. **Make it easy for them to tell you they want more** (clear CTA to next step)

**The 3 Types of Lead Magnets:**
1. **Reveal Problem:** "Diagnosis" type. Shows them a problem they don't know they have. (e.g., free audit, assessment, inspection)
2. **Sample/Trial:** Short-term access to your service. (e.g., 3-day trial, free first session, sample)
3. **Free Tool:** Calculator, template, checklist, guide. Solves the narrow problem completely.

**Lead Magnet vs. Core Offer Math:**
- Core offer: $100 CAC, 1% convert from ads
- Lead magnet ($25 to deliver): $100 → 3x more engaged leads → 3x more customers → **Same $100 net CAC but 3x the customers**
- When you nail the lead magnet, you triple your business with the same ad spend.

---

## SECTION II: THE CORE FOUR ADVERTISING METHODS

The **only** four ways to let people know about what you sell:

| Method | Audience | Format | Description |
|--------|----------|--------|-------------|
| **Warm Outreach** | Warm (people who know you) | 1-to-1 (private) | Contact your existing network directly |
| **Post Free Content** | Warm (your audience) | 1-to-many (public) | Grow and monetize your audience |
| **Cold Outreach** | Cold (strangers) | 1-to-1 (private) | Reach out to strangers directly |
| **Paid Ads** | Cold (strangers) | 1-to-many (public) | Pay platforms to put your offer in front of their audience |

**If you're not getting enough leads, you're either:**
- Not doing the core four with enough SKILL
- Not doing the core four with enough VOLUME
- Not doing the core four in enough PLACES

---

## CORE FOUR METHOD #1: WARM OUTREACH

**What it is:** 1-to-1 contact with people who already know you — friends, family, followers, past customers, contacts.

**Benchmark:** 1 in 5 contacts should engage. 1 in 5 who engage should take the free offer. 1 in 4 who take the free offer converts to paid. = 1 customer per 100 reach-outs.

**The Math:** 500 warm reach-outs/week × 1% convert × $400 product = **$2,000/week = $104,000/year**

### 10-Step Warm Outreach Process

**Step 1: Get Your List**
- Phone contacts
- Email contacts/address book from all accounts
- All social media: followers, friends, connections
- Add them up — you have more than you think (often 1,000+)

**Step 2: Pick a Platform**
- Start with the platform you have the MOST contacts on
- You'll hit them all eventually

**Step 3: Personalize Your Message**
- Use something you know about them as your reason to reach out
- Check social media for recent updates if needed
- Never lead with the ask — pay social dues first

**Step 4: Reach Out to 100 People Per Day**
- Contact up to 3 times (once per day for 3 days, or until response)
- Phone call, text, email, DM, voicemail — whatever fits the platform
- Physical mail: once per week

**Step 5: Use the ACA Framework When They Respond**
- **A**cknowledge: Restate what they said in your own words
- **C**ompliment: Tie to a positive character trait
- **A**sk: Lead conversation toward your offer topic

*Example: "Two kids and you're an accountant… Wow! Supermom! So hardworking managing a career and two kids. Do you ever get time for yourself?"*

**Step 6: Make the Offer (After 3–4 Exchanges)**

Use this script:
> "By the way, do you know anybody who is [describe their struggles] looking to [dream outcome] in [time delay]? I'm taking on five case studies for free, because that's all I can handle. I just want to get some testimonials. I help them [dream outcome] without [effort and sacrifice]. It works — I even guarantee it or I work with them until they do. I just had someone named [name] get [result] even though they had [same struggle]. Does anyone you like come to mind? …and if not, anyone you hate? (ha)"

**Key:** You're asking if they know anyone, not if they want to buy. Most people who say "yes" say they're interested themselves.

**Value Offer Formula:**
> "I help [ideal customer] get [dream outcome] in [time period] without [effort and sacrifice] — and I guarantee [result] or [consequence]."

**Step 7: Make It Easy to Say Yes — Make It Free**
- First 5 clients: FREE, in exchange for feedback + killer review if warranted
- Benefits: you get reps, they're forgiving, you get testimonials, they send referrals, some convert to paying

**When they say no:** Ask "What would I have to do to make this worth it for you?" Their answers are a roadmap to closing the next 10 people.

**Step 8: Start Back at the Top**
- After reaching out to everyone on Platform 1, switch to Platform 2
- After Platform 2, switch to Platform 3
- Cycle repeats

**Step 9: Start Charging**
- When people start referring → you're "good enough" to charge
- Sequence: Free → 80% off (next 5) → 60% off → 40% off → full price
- "I increase my prices every five clients" creates real urgency

**Step 10: Keep Your List Warm**
- Give regular value (content, tips, updates) to keep list primed
- **Dean Jackson's 9-Word Email:** "Are you still looking to [4-word desire]?" — just a question, no links, no frills
- *Examples: "Are you still looking to buy your dream home?" / "Are you still looking to cut your ad costs?"*

---

## CORE FOUR METHOD #2: POST FREE CONTENT

**What it is:** Build an audience by consistently publishing valuable content for free. The content disappears; the audience compounds.

**Key Insight:** Volume beats quality every time at the early stage. Post more.

### The Content Unit — Three Components
Every piece of audience-growing content must:
1. **Hook Attention** — get them to stop scrolling and notice you
2. **Retain Attention** — keep them consuming
3. **Reward Attention** — satisfy the reason they consumed (deliver on the hook)

**Hook quality** is measured by % of people who start consuming your content. This is your most important variable.

### Topic Categories for Hooks
- **Far Past:** Important life lessons. "Give them the story without the scar."
- **Recent Past:** From meetings, calls, interactions this week. Testimonials and case studies.
- **Present:** Ideas that occur to you in real time. Note them immediately, post publicly.
- **Trending:** Apply your expertise to what's currently in the news or culture.
- **Manufactured:** Experiments, tests, research you run specifically for content.

### Monetizing Your Audience (Content Part II)
Once you have an audience, make offers within your content:
1. **Soft CTA:** Mention your offer naturally in content ("If you want help with X, DM me")
2. **Hard CTA:** Explicit offer at end of content ("Click the link below to get [lead magnet]")
3. **Organic Referrals:** Content that gets shared expands audience for free

**Rule:** Give value consistently, then ask. The "give-ask" ratio determines audience trust and conversion rate.

---

## CORE FOUR METHOD #3: COLD OUTREACH

**What it is:** 1-to-1 private advertising to strangers. The more advanced cousin of warm outreach — not limited by your existing network.

**Timeline expectations:** Cold outreach takes 6–12 months to build into a reliable machine. Set expectations accordingly.

**Real example:** Hormozi's cold outreach team: Month 1 = $0, Month 5 = $160k, Month 9 = $480k+, eventually = millions/month.

### Three Problems Cold Outreach Solves (In Order)

**Problem 1: You don't have a way to contact them**

**Build Your List — Three Methods:**
1. **Scraping Software:** Search lead databases (search "outbound leads scraping tool"). Test 200–300 contacts before scaling.
2. **List Brokers:** Pay brokers to assemble targeted lists. Test samples from multiple brokers.
3. **Elbow Grease (Manual):** Join groups/communities where your audience gathers. Manually compile contact info. Most fresh/least contacted — worth the time for hard-to-reach audiences.

*Work from most accessible → least accessible.*

**Problem 2: They ignore you**

**Key tactics:**
- **Personalize to look warm:** 1–3 pieces of specific information a friend might know about them
- Research their LinkedIn, recent content, company news
- Reference specifics before your pitch

**Cold Call/Email Script Formula:**
> "[Their name] — [pause]. I [watched/read] [specific thing you know about them]. [Relevant compliment]. [Brief value proposition: "We helped [similar company] get [result]."] Would you be opposed to a 15-minute call to see if we could do the same for you?"

**Sample Cold Email Structure:**
1. Personal opener (something specific about them)
2. One-sentence credibility proof (result you got for similar company)
3. Value-oriented offer (specific outcome, fast, without downside)
4. Simple single CTA ("Worth a 15-min call this week?")

**Problem 3: They're not interested**

**Solution: Big Fast Value**
- Overwhelm them with value upfront before asking for anything
- Share a relevant case study/result immediately
- Make the ask tiny (a call, not a commitment)

### Cold Outreach Numbers Game
- Cold = much lower response rates than warm (expect 1–3% reply rate on cold email)
- **Solution: Volume + Persistence**
- Contact them via multiple channels (email + LinkedIn + phone)
- Follow up multiple times (5–7+ touches before giving up)
- Most deals close on follow-up #5–7, not the first contact

---

## CORE FOUR METHOD #4: PAID ADS

**What it is:** Pay platforms to put your offer in front of their cold audience. Trade money for reach. Fastest path to maximum eyeballs.

**Key principle:** If ads aren't profitable, it's usually because the right people never saw them. Fix targeting before changing the offer.

**Ads are an efficiency game.** Goal: maximize the ratio of leads generated to money spent.

### 4-Step Paid Ads Framework

**Step 1: Choose a Platform**
Pick a platform where all four are true:
- You've used it as a consumer and understand how it works
- You can target people interested in your stuff
- You know how to format ads for that platform
- You have the minimum budget to test

**Step 2: Targeting**
Two methods (use both):
1. **Lookalike Audience:** Upload your customer list. Platform finds people similar to your best buyers.
2. **Interest/Demographic Targeting:** Filter by age, income, gender, location, interests that correlate with buyers.

*The more specific the list → more efficient but burns faster. Start specific, then broaden as you learn.*

**Step 3: Making the Ad**

**What to advertise:**
- Core offer (direct to sale) — test this first; some businesses don't need lead magnets
- Lead magnet (indirect to sale) — better for high-ticket or complex buying decisions

**The Only AD you need (Hormozi's original winner):**
> "I'M LOOKING FOR 5 [LOCATION] RESIDENTS TO TAKE PART IN A FREE [X-WEEK CHALLENGE]. YOU MUST LET US USE YOUR BEFORE AND AFTER RESULTS IN OUR MARKETING IN EXCHANGE FOR THE PROGRAM. CLICK LINK TO SIGN UP: [LINK]"
*No images. No video. Just words. It worked. This format became $1.5B+ in gym revenue.*

**Ad structure:**
- Hook (stops the scroll)
- Identify the problem/person (avatar call-out)
- Credibility proof (result for someone like them)
- Offer (specific, time-bound, low-risk)
- CTA (one clear next step)

**Step 4: Permission to Contact (Getting the Lead)**
- Drive to landing page that captures contact info
- Offer lead magnet or book a call in exchange for name/email/phone
- Engaged lead = they gave their info

### Paid Ads Economics

**Client Acquisition Cost (CAC) calculation:**
```
Total ad spend ÷ Total customers acquired = CAC
```

**LTGP:CAC Target:** The goal is **3:1 minimum** (for every $1 spent acquiring a customer, make $3 in lifetime gross profit).

**LTGP:** Lifetime Gross Profit = Gross profit per period × Number of periods × Retention

**If CAC is too high:**
- Is it an advertising problem? (Wrong audience → leads don't have the problem/money)
- Is it a sales problem? (Qualified leads are coming but not buying)
- **Diagnosis question:** "Do my engaged leads have the problem I solve AND the money to spend?"

**Scaling paid ads:**
- Test in small, specific audience (high efficiency)
- Once profitable, expand to larger/broader audiences
- Ratio goes down but total revenue goes up
- Keep testing and expanding until market is truly exhausted (rarely happens)

---

## MORE, BETTER, NEW — MAXIMIZING THE CORE FOUR

When you've maxed one method and want more leads:

### Step 1: MORE
Double inputs before changing anything. 2x ad spend, 2x outreach, 2x content. You'll likely get 2x leads.

**The Rule of 100:**
Commit to 100 primary actions every day for 100 days straight.
- Warm outreach: 100 reach-outs/day
- Content: 100 minutes/day making content; post at least 1/day
- Cold outreach: 100 reach-outs/day
- Paid ads: 100 minutes/day making ads + 100 days running them

### Step 2: BETTER
After maximizing volume, identify and fix the **constraint** (the step with the biggest drop-off).

**Constraint Analysis:**
- Map all steps in your lead process (ad → click → opt-in → apply → schedule → show → close)
- Find the step with the biggest % drop-off
- A 5% improvement at a 5% step = 100% increase in leads vs. 5% improvement at a 50% step = 10% increase

**Testing Protocol:**
- Test ONE thing per week per platform
- Run tests for at least one full week before evaluating
- Log all results (never test the same thing twice without referencing prior data)
- Move to next constraint once current is optimized

### Step 3: NEW
When more + better yield diminishing returns, expand:
1. New placements on same platform (Stories, Shorts, different ad types)
2. New platforms (Instagram → YouTube → LinkedIn → podcast ads)
3. New core four activity (add cold outreach if only doing content)

*Order: New placements → New platforms → New core four activity*

**The Size of the Pie Fallacy:** Most entrepreneurs think they've "saturated" their market when they've barely touched it. A $2M/yr chiropractor marketing company thinking they've saturated the $15.1B chiropractic industry after spending $30k/mo on ONE platform is the example. Don't be this person.

---

## SECTION III: LEAD GETTERS (LEVERAGE)

Instead of YOU doing the core four, get OTHERS to do it for you. Lead getters are higher-leverage because there are more of them than there are of you.

### The 4 Scenarios of Leverage

| Scenario | Work | Leads | Leverage |
|----------|------|-------|----------|
| You do the core four alone | HIGH | LOW | LOW |
| One lead getter does it for you | LOW | LOW | HIGH |
| Many lead getters doing it | HIGH | HIGH | HIGHER |
| Lead getter who gets lead getters | LOW | HIGH | HIGHEST |

### Lead Getter #1: Customer Referrals

**The highest-ROI lead source.** Gym Launch shut off paid ads accidentally for 2 weeks — still did $500k/week from word of mouth alone. At a 700-person conference, >50% had come from referrals.

**How to maximize referrals:**
1. **Deliver exceptional results.** The product must actually work.
2. **Build a referral program** with meaningful incentives ($100–$500 cash, account credits, free services)
3. **Ask explicitly.** After getting a great result with a client: "Who else do you know who has [the same problem]?"
4. **Make referral asking systematic.** Script it, train your team to ask, track referral rates.
5. **Referral program structure:**
   - Existing customer refers someone → referring customer gets [incentive]
   - New customer closes → referring customer gets paid/rewarded
   - Make the incentive worth talking about (not a $5 Starbucks card)

**Benchmark:** Target 25%+ of new customers from referrals before aggressively scaling paid advertising again.

### Lead Getter #2: Employees

**Hire people to do the core four on your behalf.** A media buyer, cold outreach specialist, content creator, or SDR is just an employee doing advertising for you.

**Key insight:** Anyone can be taught to advertise. It's not about brains — it's about guts and training.

**Employee advertising ROI calculation:**
```
Total payroll ÷ Total engaged leads = Cost per engaged lead
Cost per engaged lead × Leads per customer = CAC from employees
```

**Example:** $100k/mo in content team payroll → 30,000 leads/mo = $3.33/engaged lead

**Diagnosis:** If employee CAC is high:
- Ask: "Do my engaged leads have the problem I solve and the money to spend?"
- If no → **advertising problem** (wrong people seeing your content/ads)
- If yes → **sales problem** (right people aren't converting)

### Lead Getter #3: Agencies

**Right way to use agencies:** Learn from them, then build the skill in-house.

**Hormozi's Agency Framework:**
> "I want to do what you do in my business. I'd like to work with you for 6 months to learn how. I'll pay extra for you to explain your decisions. Then I'll train my team. Then we shift to consulting only. Are you opposed to this?"

**Most good agencies will say yes.** Start with a "good enough" agency, then bring in a more elite agency to refine. Your team gets better over time while the agency cycles its best people to new clients.

**When to use agencies:**
- Learning new advertising methods
- Entering new platforms you don't understand yet
- When you need faster results than trial-and-error allows

**How to pick a good agency:**
1. Someone you personally know got good results with them (referral-only = best signal)
2. Recognizable companies got results with them
3. They have a waiting list (demand > supply)
4. Realistic expectations, clear timelines, no short-term hacks
5. Clear metrics, regular updates in plain language
6. Their offer passes the Value Equation test
7. They're expensive (necessary but not sufficient)

### Lead Getter #4: Affiliates

**Definition:** An independent business that tells their audience about your stuff in exchange for money, free products, or both.

**Why affiliates are the highest leverage lead getter:**
- Each affiliate adds a permanent new stream of engaged leads
- They operate independently (no management required once activated)
- A single super-affiliate can bring hundreds of businesses who each bring thousands of leads

**ALAN example:** 1 super-affiliate → 10 agencies/month → 50 local businesses/month → 2,500 leads/month = $12,500/mo. And it grew every month after.

### 6-Step Affiliate Army Building Process

**Step 1: Find Your Ideal Affiliates**
Ask these questions about your best customers:
- What do they buy? → Who provides that?
- Where do they go? → What businesses are nearby?
- What do they like to do? → Who provides those services?
- For B2B: What types of businesses do they work for?

*The question: "Who's got my leads?"*

**Step 2: Make Them an Offer**
- Call out affiliate business owners directly
- Frame the offer around making them more money: "Earn [commission] promoting [product] to your existing clients — no fulfillment, no support, start tomorrow"
- Use Value Equation: dream outcome + perceived likelihood + fast + minimal effort

**Step 3: Qualify Them**
- Make them a customer first (if they use/buy the product, they'll sell it better)
- Get them to invest time (attending training) or money (buying the product)
- "If they pay, they pay attention"

**Step 4: Figure Out What to Pay Them**
- **Revenue share:** Most common. 10–30% of revenue they generate.
- **Per-lead/per-sale flat fee:** Simpler tracking, predictable for affiliates.
- **Tiered commissions:** Earn more as they send more volume.
- **Hybrid:** Flat fee + percentage over threshold.
- **Key:** Make it meaningful enough that affiliates prioritize your offer over alternatives.

**Step 5: Get Them Advertising**
- Provide turnkey materials: ads, scripts, email templates, social posts
- Run a "launch event" — live training, excitement, social proof, countdown
- Make the first sale happen as fast as possible (prove it works immediately)
- BAMFAM: Book-A-Meeting-From-A-Meeting — schedule training calls back-to-back

**Step 6: Keep Them Advertising**
- Celebrate wins publicly (affiliate leaderboards, shoutouts)
- Regular communication (monthly performance updates)
- Keep improving the product (better product = happier affiliates = more promotion)
- Pay fast and accurately (trust = affiliate loyalty)
- Run seasonal promotions to re-activate dormant affiliates

---

## THE ONE-PAGE ADVERTISING PLAN

### Daily Action Framework

**Step 1:** Pick the type of engaged lead to get today (Customers, Affiliates, Employees, or Agencies)

**Step 2:** Pick Rule of 100 or Open to Goal

**Step 3:** Fill out the advertising checklist for that activity

**Step 4:** Do the activity until you have enough revenue to pay someone else to do it

**Step 5:** Go back to Step 1 with employees as your new target

### Open to Goal Framework
- Don't commit to actions — commit to outcomes
- Work until you hit X new leads, X calls booked, X clients closed
- "Do more than they do, and you will have more than they have"

**Hormozi's High-ROI Habit Stack:**
1. Wake up early (4–5am)
2. No rituals — coffee + get to work immediately
3. No meetings until noon (uninterrupted advertising work)

### The Advertising Roadmap (7 Levels)

| Level | Status | Primary Action |
|-------|--------|----------------|
| 1 | Getting first leads | Warm outreach — 100/day |
| 2 | Consistent customers, maxing personal capacity | Warm outreach + free content, maximize volume |
| 3 | Need more than personal capacity | Hire employees to do advertising for you |
| 4 | Product good enough for consistent referrals | Focus on product excellence, build referral program |
| 5 | Multiple platforms, multiple methods | Expand to new platforms, lead getters, core four activities |
| 6 | Department-level advertising | Hire experienced advertising executives to run departments |
| 7 | $1B+ (to be determined) | TBD |

---

## APPLICATION TO YOUR BUSINESSES

### [BUSINESS NAME] (B2B / Service Business Example)

**Warm Outreach Priority:**
- List every consultant, contact, agency rep, and past client in your network
- Apply ACA framework + "do you know anyone" script
- Offer: "Free audit — we'll show you exactly where [problem] is costing you and what [solution] would change"
- Script: "I'm only doing 3 free audits this month because it takes real time. If you don't find value, you owe us nothing. Who do you know dealing with [problem] right now?"

**Affiliate Strategy (Highest Leverage):**
- Target: Complementary service providers who already serve your ideal client
- Offer: "Refer a client. We split our margin with you — flat [AMOUNT] per [deal/project] placed."
- The best affiliates already have the relationships your business needs.

**Content Strategy:**
- LinkedIn/social content about your niche, strategy insights, benchmarks
- Case studies: "We [delivered result] for [type of client] at [X]% better than industry average"
- Lead magnet: "[Year] [Industry] Rate Card — What You're Actually Paying vs. Market"

### [BUSINESS NAME] (Real Estate / Motivated Seller Example)

**Cold Outreach (Motivated Sellers):**
- Lists: Pre-foreclosure, probate, tax delinquent, out-of-state landlords, divorce filings
- Scraping tools + broker-assembled lists
- Script: "Hi [Name], I'm a local investor. I noticed your property at [address] — I buy homes in any condition, fast, and can work around your timeline. Not looking to low-ball you. Would a fair, no-hassle offer be worth 10 minutes of your time?"

**Affiliate Strategy (Wholesale Buyers/Investors):**
- Target: Real estate agents, other wholesalers, property managers, attorneys (probate/divorce)
- Offer: "I bring you off-market deals below market with creative financing. You keep the spread or the flip profit. I take an assignment fee."
- Tap into existing investor communities for warm audiences.

**Content (Lead Magnet):**
- "The [X] Questions Every [Seller/Buyer] Should Ask Before Signing Anything"
- "How [Strategy] Works in [Your State]: The Honest Explanation"
- Target: Facebook groups, Reddit real estate, local community groups

### [BUSINESS NAME] (Home Services / Local Business Example)

**Warm Outreach:**
- Every past customer, neighbor, referral network
- Script: "We just completed a project for [mutual contact]. Did you know [relevant stat about the problem]? We're doing a free assessment this month — 30 minutes, no obligation."

**Cold Outreach (Geotargeted):**
- Neighborhoods with your ideal customer profile
- Door knocking (physical) + direct mail
- Partner with: Complementary service providers who already touch your target homeowner

**Paid Ads:**
- Facebook/Instagram geo-targeted by zip code
- Trigger events: After relevant events in your service area
- "[Solve Problem] — Free [Assessment/Consultation]"

**Affiliate Program:**
- Complementary trade/service providers in your area
- Offer: "Refer a [job type]. We pay you [AMOUNT] per completed [job]."
- Local referral partners with aligned client bases — natural referral incentive

---

## QUICK REFERENCE: CORE FOUR BENCHMARKS

| Method | Expected Engagement Rate | Time to Results |
|--------|--------------------------|-----------------|
| Warm Outreach | 20% reply; 4% take offer; 1% convert | Days–weeks |
| Free Content | Compound; 0.1–2% engagement per post | 3–12 months to meaningful audience |
| Cold Outreach | 1–3% reply rate | 6–12 months to reliable machine |
| Paid Ads | Varies; target 3:1 LTGP:CAC | Days to first leads; weeks to profitable |

**Rule of 100 Daily Commitments:**
- Warm outreach: 100 personalized reach-outs
- Content: 100 minutes creating; 1+ posts published
- Cold outreach: 100 outbound contacts
- Paid ads: 100 minutes improving ads; $X/day running them

**Lead Magnet Math Rule:** If you can get 3x more people into your funnel for the same spend with a free lead magnet, use one.

**Open to Goal:** Define the outcome. Do whatever it takes to hit it. Never stop because the clock says so.
