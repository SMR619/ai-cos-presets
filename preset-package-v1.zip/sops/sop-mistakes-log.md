# SOP: Mistakes Log

**Purpose:** Track operational and judgment mistakes so the agent improves over time — not just within a session, but permanently.
**File location:** `memory/mistakes.md`
**When to use:** Immediately after any mistake, failed approach, or owner correction.

---

## Why This Exists

AI agents don't automatically learn from mistakes between sessions. Without a log, the same mistake can happen again and again. The mistakes log is a simple pattern-detection tool: write it down once, read it before working in that domain again, avoid repeating it.

---

## When to Log

Log an entry when:
- The agent tried something that failed (API call, tool use, wrong approach)
- The owner had to correct the agent
- A workaround was found for a broken process
- The agent made a judgment call that turned out to be wrong
- Something was forgotten and caused a problem

---

## The Format

```
[YYYY-MM-DD] What went wrong — Root cause — Corrected: YES/NO
```

**Rules:**
- One line per mistake. Under 20 words.
- No essays, no explanations. Just the pattern.
- If not yet corrected, mark `Corrected: NO` and add a rule or fix before marking it YES.

**Examples:**
```
[2026-04-09] Tried web_fetch on YouTube instead of API — forgot API existed — Corrected: YES
[2026-04-09] Sent email without confirming what "the problem" meant — should have clarified first — Corrected: N/A
[2026-03-31] Referenced outdated project workflows — didn't read STATUS.md first — Corrected: YES
```

---

## File Structure

```markdown
# Mistakes Log
**Purpose:** Pattern detection and behavior correction. Read when working in the same domain as a past mistake.
**Format:** [YYYY-MM-DD] What went wrong — Root cause — Corrected: YES/NO

---

## Operational Mistakes
[entries here]

## Judgment Mistakes
[entries here]

---
*Last updated: [date]*
```

---

## When to Read

At the start of any session where you'll be working in the same domain as a past mistake:
- About to send emails → check email-related mistakes
- About to work on a deal → check deal/CRM mistakes
- About to use a specific API or tool → check tool-related mistakes
- Owner mentions a recurring issue → scan all entries

You don't need to read the whole file every session. Scan for relevant entries based on what you're about to do.

---

## Correcting a Mistake

When a mistake is corrected (a rule is added, a process is fixed, a setting is changed):
1. Update the entry: change `Corrected: NO` to `Corrected: YES`
2. If a rule was added to `AGENTS.md` or `MEMORY.md`, note that in the correction
3. Update the "Last updated" date

---

## Note

This log is for the agent's use. It doesn't need to be shared with the owner unless they ask. Its only job is to make the agent smarter.
