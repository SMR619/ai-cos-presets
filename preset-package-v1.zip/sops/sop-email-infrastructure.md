# SOP: Email Infrastructure Setup

**Purpose:** Connect the agent's email account so it can send and receive emails on the owner's behalf.
**When to use:** During onboarding, after the owner confirms their email provider.
**Time required:** 10–20 minutes depending on provider.

---

## Why This Matters

Without email access, the agent can answer questions but can't act on them. Email is the connective tissue of business: outreach, follow-ups, deal communications, vendor management. Once connected, the agent can:

- Send emails on your behalf (drafts for your review, or autonomously when authorized)
- Monitor inboxes and surface what needs attention
- Sync all sent/received email to your CRM contact records (see `sop-ghl-email-sync.md`)
- Keep deal and contact history without manual logging

---

## Option 1: Microsoft 365 / Outlook (Recommended)

**Why recommended:** Microsoft Graph API is reliable, well-documented, and supports both read and send without risk of deprecation. Best for business accounts.

**Setup steps:**
1. Owner provides their Microsoft 365 / Outlook business email address
2. In Azure Active Directory (or Entra ID), register a new app:
   - Go to portal.azure.com → Azure Active Directory → App registrations → New registration
   - Name: "AI Chief of Staff" (or the agent's name)
   - Supported account types: Accounts in this organizational directory only
3. Add API permissions:
   - Microsoft Graph → Application permissions → `Mail.ReadWrite`, `Mail.Send`
   - Grant admin consent
4. Create a client secret (Certificates & Secrets → New client secret)
5. Note: Tenant ID, Client ID, Client Secret
6. Store in `credentials.env`:
   ```
   EMAIL_TENANT_ID=[your tenant ID]
   EMAIL_CLIENT_ID=[your client ID]
   EMAIL_CLIENT_SECRET=[your client secret]
   EMAIL_ADDRESS=[your@business.com]
   ```
7. Test with a send script before confirming complete

**What the agent can do:**
- Send email as that address
- Read inbox, search emails
- Full send/receive with audit trail

---

## Option 2: Google Workspace (Paid G Suite)

**Why this works:** Google Workspace (paid) supports OAuth 2.0 service accounts with proper API access.

**Setup steps:**
1. Owner provides their Google Workspace business email
2. In Google Cloud Console:
   - Create a new project (or use an existing one)
   - Enable Gmail API
   - Create a Service Account
   - Enable domain-wide delegation for the service account
3. In Google Workspace Admin:
   - Go to Security → API Controls → Domain-wide Delegation
   - Add the service account's Client ID with scopes:
     - `https://www.googleapis.com/auth/gmail.send`
     - `https://www.googleapis.com/auth/gmail.modify`
4. Download the service account JSON key file
5. Store credentials securely in `credentials.env` or as a referenced file
6. Test before confirming complete

**Note:** Takes 15–20 minutes. Less turnkey than M365.

---

## Option 3: Personal Gmail

**What works:** Gmail App Password (requires 2-factor auth)
**Caveat:** Google could deprecate App Passwords. For long-term reliability, upgrade to Google Workspace or M365.

**Setup steps:**
1. Ensure 2-factor authentication is enabled on the Gmail account
2. Go to myaccount.google.com → Security → App Passwords
3. Create a new App Password (label it with the agent's name)
4. Store in `credentials.env`:
   ```
   GMAIL_ADDRESS=[your@gmail.com]
   GMAIL_APP_PASSWORD=[16-character app password]
   ```
5. Agent uses SMTP with TLS (smtp.gmail.com, port 587)

**Recommendation:** Mention to the owner that M365 is ~$6/month and much more stable long-term.

---

## Option 4: Custom SMTP

**When to use:** Custom domain hosted by any provider (Zoho, FastMail, namecheap, Hostgator, etc.)

**Setup steps:**
1. Owner provides (or gets from their email provider):
   - SMTP host (e.g. `smtp.zoho.com`)
   - Port (usually 587 for TLS, 465 for SSL)
   - Username (usually the email address)
   - Password or App Password
2. Store in `credentials.env`:
   ```
   SMTP_HOST=[smtp.yourprovider.com]
   SMTP_PORT=587
   SMTP_USER=[your@business.com]
   SMTP_PASSWORD=[your password or app password]
   ```
3. Test before confirming complete

---

## After Setup — Log in MEMORY.md

```
## Email Configuration
- Business email: [their address]
- Provider: [Microsoft 365 / Google Workspace / Gmail / Custom SMTP]
- Auth method: [Graph API / OAuth / App Password / SMTP]
- Status: configured ✅
- Notes: [any caveats]
```

---

## Multiple Email Addresses

If the owner has multiple businesses, each with its own email, set up one account per business. Create a routing table in MEMORY.md:

```
| Context | Email Address | Account Key |
|---------|--------------|-------------|
| Business 1 | name@business1.com | biz1 |
| Business 2 | name@business2.com | biz2 |
```

The agent should always send from the contextually appropriate address.

---

## Email Monitor Cron — Best Practices (added 2026-04-24)

When setting up email monitor cron jobs to watch inboxes and alert the owner:

### Critical Rules

**1. Filter by unread only**
Always filter `$filter=isRead eq false` in the Graph API call. This prevents the cron from re-alerting on emails already handled by the agent in an active session.

```
GET /users/{email}/mailFolders/Inbox/messages?$filter=isRead eq false&$top=10&$select=id,subject,from,receivedDateTime
```

**2. Mark emails as read when handled in an active session**
When the agent reads and responds to an email during a live session, immediately mark it as read via PATCH:

```python
requests.patch(
    f"https://graph.microsoft.com/v1.0/users/{email}/messages/{message_id}",
    headers=headers,
    json={"isRead": True}
)
```

This ensures the cron won't re-surface it on its next run.

**3. Never alert on emails you just sent**
Sent items and MAILER-DAEMON bounces are noise. Filter them out:
- Skip emails from `mailer-daemon`, `postmaster`, `noreply`, `no-reply`
- Skip emails where the sender matches the monitored inbox address

**4. Active session awareness**
Crons run isolated — they don't know what's been handled in the active session. The `isRead` flag is the shared state that bridges them. Always use it.

**5. Alert only on genuinely actionable emails**
The cron should:
- Read the full body (not just preview) before deciding to alert
- Skip automated/marketing/notification emails
- Only Telegram the owner when a HUMAN sent something that requires a decision or response

### Why This Matters
Without unread filtering, every email monitor run re-alerts on the same emails the agent just handled — creating noise and eroding owner trust. The read/unread flag is the simplest reliable dedup mechanism.
