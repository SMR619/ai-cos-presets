# SOP: Memory Architecture — Three Tiers

**Purpose:** Explains how memory is structured, what lives where, and when to read each tier.
**Why this exists:** A flat memory file that grows without limit becomes slow and expensive. A tiered system keeps per-message token cost low while ensuring nothing important is lost.

---

## The Three Tiers

### Tier 1 — Always Loaded: `MEMORY.md`

**What it is:** The agent's always-on working memory. Read at the start of every session.

**What belongs here:**
- Active flags and urgent reminders
- Email configuration and routing rules
- Key infrastructure (cron IDs, critical scripts, key file paths)
- Business priority stack (top-line overview only)
- Working preferences
- Session history (one-liner per session, link to daily file)
- Pointers to Tier 2 and Tier 3 files

**What does NOT belong here:**
- Detailed project histories
- Full deal context
- Lengthy descriptions of businesses or people
- Anything that hasn't changed recently

**Target:** Under 150 lines. If it grows beyond that, archive older entries to daily session files and trim.

**Rule:** If something in MEMORY.md is more than a pointer or a flag, it's probably in the wrong tier.

---

### Tier 2 — On Demand: `wiki/*.md`

**What it is:** Domain knowledge files, organized by topic. Read when the relevant domain comes up in conversation.

**When to read:**
- Owner mentions a specific business → read that business's wiki file
- Discussing a specific person or contact → read the contacts/people wiki
- Making a decision that touches rules or preferences → read the rules wiki
- Executing a recurring task → read the instructions wiki

**Typical wiki files:**
- `01-businesses.md` — details on each business
- `02-deals.md` — active deals, pipeline details
- `03-people.md` — key contacts, relationships
- `04-rules.md` — permanent rules and preferences
- `05-tools.md` — tools, credentials, infrastructure details
- `06-instructions.md` — standing operational instructions

**Rule:** Never rely solely on MEMORY.md for details about a specific business, deal, or person. Read the relevant wiki file first.

---

### Tier 3 — Deep Archive: Project files and daily notes

**What it is:** The detailed historical record. Read only when that specific thing is being discussed.

**Includes:**
- `/data/syncthing-workspace/projects/[project-name]/STATUS.md` — current state of each active project
- `memory/YYYY-MM-DD.md` — daily session notes (full detail of what happened that day)
- Deal files, proposal files, contract files

**When to read:**
- Before discussing a specific project → read its `STATUS.md`
- Owner references something from a past session → find and read that session's daily note
- Resolving a specific deal or contract → read the deal file

**Rule:** Always read the project `STATUS.md` before discussing a project with the owner. Never answer from context memory alone — context memory is only as fresh as the last session load.

---

## How the Tiers Work Together

**Example: Owner asks about a real estate deal**

1. **Tier 1 check (already loaded):** MEMORY.md shows "Business Priority Stack → [Business Name] — deals in progress" and a pointer to `wiki/02-deals.md`
2. **Tier 2 read:** Open `wiki/02-deals.md` — read current deal summaries, which deal this might be
3. **Tier 3 read:** Open `projects/[deal-name]/STATUS.md` — read the actual deal details, last status, open questions
4. **Answer from the file** — not from whatever happened to be in context

**Why this is better than a flat MEMORY.md:**
- Tier 1 stays fast — under 150 lines loaded every session
- Tier 2 adds detail only when needed — no token waste on irrelevant domains
- Tier 3 adds precision only when that specific thing is discussed — keeps the most expensive reads for the most specific questions

---

## Maintenance Rules

**Tier 1 (MEMORY.md):**
- Trim to under 150 lines at least once a month
- When a flag is resolved, remove it
- When infrastructure changes, update the relevant entry
- Session History: one-liner per session + link to daily file

**Tier 2 (wiki/*.md):**
- Update the relevant wiki file when something substantive changes in that domain
- Don't wait for a "save checkpoint" — update when decisions are made

**Tier 3 (project and daily files):**
- Update `STATUS.md` immediately when decisions are made about that project
- Daily session notes: write at end of session or on "save checkpoint"
- Don't delete old daily files — they're the audit trail

---

## The Golden Rule

> If it's not written down somewhere in the three tiers, it doesn't exist across restarts.

Memory within a session is real. Memory across restarts is only what's in the files.
