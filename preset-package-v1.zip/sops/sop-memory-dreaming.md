# SOP: Nightly Dreaming — Memory Consolidation

**Purpose:** Automatically surface memory gaps and consolidate durable facts into permanent files every night while the owner sleeps.
**When:** Runs nightly via cron at ~3 AM local time. Set up during onboarding — not optional.

---

## What Dreaming Actually Does

Dreaming is a nightly background process that does three things:

1. **rem-harness** — Scans all daily session notes and identifies patterns, recurring facts, and durable truths
2. **promote** — Scores candidates and writes any high-confidence items (≥0.7) to long-term memory
3. **Gap analysis** — Compares today's session notes against permanent files (MEMORY.md, OPERATING_RULES.md, AGENTS.md) and writes anything that was missed during the day

The gap analysis is the most important step. This is the safety net: even if the agent didn't write something to memory mid-session, dreaming catches it overnight.

---

## What Gets Promoted to Long-Term Memory

The system looks for:
- Standing decisions the owner made that should never be re-asked
- Preferences expressed about how to work together
- Rules established for how the agent should behave
- Contacts added or updated
- Tools configured or connected
- Recurring patterns in how the owner operates

Things that do NOT get promoted:
- One-time operational events (sent an email, ran a report)
- Emotional signals or frustrations (noted but not codified)
- Items already captured in OPERATING_RULES.md or AGENTS.md

---

## Cron Setup (Required During Onboarding)

Add this cron job during onboarding via the OpenClaw cron tool:

```
Name: Nightly Dreaming — Memory Consolidation
Schedule: 0 3 * * * (3 AM local time)
Timezone: Owner's timezone
Payload: agentTurn
Model: fast model (Haiku equivalent)
Timeout: 300 seconds
Session: isolated

Message:
Run the nightly memory consolidation (dreaming) process.

1. Run: openclaw memory rem-harness --path [workspace]/memory --grounded
   Capture output. If it errors, log and continue.

2. Run: openclaw memory promote --apply --min-score 0.7
   Capture output. If it errors, log and continue.

3. GAP ANALYSIS — most important step:
   Read MEMORY.md, OPERATING_RULES.md, and today's daily note.
   Look for things mentioned in today's session NOT yet in permanent files.
   Decisions, rules, preferences, contacts, tools. If gaps found — write them to the right file now.

4. Append entry to memory/dreams-log.md:
   - Date
   - rem-harness summary
   - promote results
   - gaps found and filled (or 'No gaps found')
   Keep under 10 lines. Use absolute paths.

Never fail silently — log any errors to dreams-log.md.
```

---

## Why This Matters

Memory is the biggest weakness of AI agents. Dreaming is the infrastructure that makes the "I'll remember this" promise actually true. Without it, anything the agent didn't explicitly write during a session is lost on restart.

With it: even on a bad day where the agent was busy and missed some memory writes, the nightly run catches it. The owner never has to manage memory — it just happens.

---

## Reading the Dreams Log

The dreams-log.md file at `memory/dreams-log.md` shows what was processed each night. If an entry says "No gaps found" — that's the ideal state. It means everything from the session made it into permanent files during the session itself.

If gaps are frequently found, it means the agent is not writing memory proactively enough mid-session — review AGENTS.md rules.

---

*Last updated: 2026-04-23*
