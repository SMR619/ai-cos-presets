# NEPQ — Neuro-Emotional Persuasion Questioning — SOP

**Source:** *NEPQ Black Book of Questions* by Jeremy Miner (7th Level Inc.)
**Domain:** Sales, Persuasion, Objection Handling
**Last Updated:** 2026-03-22

---

## Core Philosophy

People buy on emotion, not logic — and they are most persuaded when they persuade **themselves**. The NEPQ system replaces external pressure (telling, pitching, pushing) with skilled questions and tonality that draw out a prospect's inner truths, create internal tension, and cause them to emotionally own both their problems and the urgency to solve them. You are not a product pusher — you are a **trusted authority and problem-finder**; the doctor who asks before prescribing. The presentation should be 10% of the conversation; the engagement stage is 85%.

---

## Key Frameworks

### The 3 Eras of Selling
- **Era 1 — Boiler Room:** Telling, pitching, pressure, "always be closing" — triggers fight-or-flight; least persuasive
- **Era 2 — Consultative:** Surface-level logical questions (SPIN) — gets surface-level, logical answers; misses emotional drivers
- **Era 3 — Dialogue (NEPQ):** Skilled questions + tonality that create internal tension and self-persuasion — most persuasive

### Internal Tension vs. External Pressure
- **External pressure** = imposed by salesperson (telling, pushing) → prospects reject conclusions
- **Internal tension** = created by skilled questions → prospects come to their own conclusions and fight for them
- "When prospects come to their own conclusions, not only will they accept them, they will fight for them."

### The GAP Model
- **Current State** = their present situation (problems, dissatisfaction)
- **Objective State** = their future once problems are solved
- **GAP** = the emotional distance between now and the desired future — your entire job is to BUILD this gap through questions

### NEPQ Time Distribution
| Stage | % of Conversation |
|-------|-------------------|
| Connection | ~5% |
| Engagement (Situation → Consequence) | ~85% |
| Transition | ~1% |
| Presentation | ~10% |
| Commitment | ~5% |

---

## The 5 Stages of NEPQ — Step-by-Step Process

---

### STAGE 1: CONNECTION STAGE

**Purpose:** Disarm the prospect (not alarm them). Create curiosity within the first 7–12 seconds. Come across as neutral, calm, and detached from the outcome of the sale — focused only on whether you can help them.

**Connection Questions — Outbound Script:**
```
"Hey [Name], this is just [Your Name] with [Company]...
It looks like you recently responded to an ad on [platform] and asked us to call you back…
about possibly helping you with [end result].
I just had a few minutes before my next appointment…
Have you found what you're looking for, or are you still looking for [end result]?"

"And do you know what you're... looking for?"

"So when you saw the ad, what was it they were going through… that caused you to… want to look into this further?"

[STATUS FRAME:]
"Now, this call is pretty basic; it's really more for us to find out about what you're using now, what results you're getting, compared to what you might be wanting, to see what that GAP looks like…
And towards the end of the call, if you feel like it... 'might be'... what you're looking for, we can talk about 'possible' next steps. Would that help you?"
```

**Connection Questions — Inbound Script:**
```
"Hey [Name], it looks like you recently booked on our calendar… about possibly getting help with [their problem] so that you can [end result], right?"

"So when you went through [ad/source], what was it about what they were saying that caused you to… want to look into this further?"

"And what were you hoping to get out of the call with us today, just so we have a better understanding?"
```

**Cold Calling Introduction:**
```
"Hey [Name], this is just [Your Name]. I was wondering if you could… help me out for a moment?"
→ "Well, I'm not quite sure who I should be talking to; I called to see who would be responsible for looking at any possible hidden gaps in your [area] that could be causing you to [problem]? Who should I be talking to about that?"
```

**30-Second Personalized Intro (for cold/networking):**
```
"Well, you know how a lot of people/companies sometimes get frustrated with [problem 1], [problem 2], and [problem 3]?
Well, what I do is, I help people/companies like that with [solution 1], [solution 2], and [solution 3].
Does that resonate with you/your company or something you might be experiencing?"
```

**Key Connection Principles:**
- Use **verbal pauses** (represented by "…") — they cause prospects to think deeper and emotionally open up
- Avoid sounding needy, eager, or salesy — signal you have other appointments, other clients
- The Status Frame is essential: frame the call as discovery (finding the GAP), not a sales pitch
- Use "might," "possible," "possibly" — softeners that lower resistance

---

### STAGE 2: ENGAGEMENT STAGE (The Core — 85% of the sale)

#### 2A: SITUATION QUESTIONS
**Purpose:** Understand their current situation. Helps both you and the prospect discover what their real situation is (most don't know until you help them uncover it).

**Generic Situation Questions:**
- "What are you doing now?"
- "What are you using now?"
- "How long have you been…?"
- "What got you involved with…?"
- "Can you walk me through what your process is for...?"
- "What type of [X] do you have now, just so I understand?"
- "How many [X] do you have so I have more context?"
- "You mentioned [issue from application]. Can you tell me a little bit more about that?"

**Verbal Cues (Bridge Questions):** Use "Ahh," "Oh, I see," "That makes sense" between questions to sound natural, not scripted. Ask 3–4 situation questions, then move on.

---

#### 2B: PROBLEM AWARENESS QUESTIONS
**Purpose:** Find out what their real problems are, root causes, and how they're negatively affecting them. Build the GAP from current state to objective state. Be a **problem-finder**, not just a problem-solver.

**Core Problem Awareness Questions:**
- "Do you like what you're...?" / "Do you like what you…?" (with verbal pause)
- "Do you want to…?"
- "What makes you feel like [current solution]'s not enough, though?"
- "So, to me, it sounds like things are going 100% perfect for you. Is there anything you would change about your [situation] if you could?"
- "So, I'm curious: what is it about your [X] that you don't like?"
- "Why would you change that?"
- "Why is that important to you now, though?"

**Two Truths Technique** (when prospect won't open up):
- "So, to me, it sounds like things are going 100% PERFECT. What would you change if you could?"
- Nobody likes 100% of what they have — this forces them to identify dissatisfaction

**Clarifying / Probing Questions:**
- "Oh, what do you mean by that?"
- "Can I ask what you mean when you said...?"
- "What do you mean by that?"
- "Let me see if I understand... So do you mean that...?"
- "You don't sound so sure about it… what don't you like?"
- "Has that… has that had an impact on you?" (verbal pace this)
- "In what way, though?"
- "How long has that been going on?"
- "Can you give me a specific example so I can understand this better?"

**NEPQ Precision Probing (Expanded):**
- "Tell me more… about that?" (curious tone)
- "How do you mean exactly?"
- "What's causing this issue?"
- "What's prompting you to look into changing this?"
- "Why is this important to you now, though?"
- "Can you be more specific? Give me an example…"
- "What would this do for you personally? In what way?"
- "What are you hoping to accomplish by us possibly working together?"
- "Tell me, what's driving the need to change your situation now, though?"
- "What would it mean for you to be able to solve this problem?"
- "How would it make you… feel though?"
- "Which of these problems are impacting you the most? Why this one, though?"
- "Are you willing to settle for that?" (challenging tone)

**Lead-In Phrases:**
- "Tell me more about that..."
- "Can you go over what you might be looking for when choosing a company to work with?"
- "Walk me through the criteria you use... to make a decision on something like this?"
- "Can you unwrap that for me so I have a better understanding?"
- "Describe for me what you're possibly looking for just to see if I could help you."
- "Explain that to me in more detail just so I understand…"
- "Can you unpack that for me a bit more…"
- "Can you go back a few pages for me so I understand that better?"

**Expanded Problem Awareness Questions (B2B especially):**
- "I mean, you've been with [vendor] for [X] years; it can't be ALL DOOM and GLOOM over there; what do you like about what they've done?" [immediately after] "What would you change if you could, though?"
- "Would you be opposed to sharing with me the top two challenges you are having now? Of these two, which one is the most important to solve?"
- "What's the biggest obstacle you're facing right now that's preventing you from solving [problem]?"
- "How much do you feel this problem is costing you in lost revenue/sales?"
- "Have you lost clients because of these issues? How much were those clients worth to you financially?"
- "How much time are you spending each day dealing with [problem]? If you were able to solve it, what would you be able to do?"
- "Have people in the company left over these issues? Do you want to change that? Why now, though?"

---

#### 2C: SOLUTION AWARENESS QUESTIONS
**Purpose:** Get prospect emotionally attached to solving the problem WITH you. Help them see their future (Objective State) once problems are solved. Uncover their ideal solution criteria so you can position your presentation perfectly.

**Part 1 — What Have They Done in the Past:**
```
"Before we started talking today, were you out there looking for [what they said they want] so you can [end result]?"

IF NO:
"What's prevented you from doing that in the past?"

IF YES:
"What did you do?"
"How did that work out?"
"What kind of results did you get from it?"
"What do you think held you back from having success…?"
```

**Criteria Question Sequence:**
```
"Let's do this… just to make sure that what we're doing could actually help you…
besides [Benefit 1] and [Benefit 2], what would you actually be looking for in [your product/service]?
Like what would be your ideal criteria?"

"Is there anything else you want?"
"Can I ask why that's important to you… now though?"
```

**Part 2 — Future State (Objective State):**
```
"How would it be different, though? You being able to [what they said they wanted]. How would your life/business be… maybe different than it is now?"

"How do you see the benefits of actually solving this problem [repeat the problem]?"

"Besides [what they already said they wanted], how do you see this benefiting you the most, though?"

"What would it do for you personally, though?"

"How would that make you… feel though?"
```

**Vendor Disruption Questions:**
- "Can I ask how does your ideal situation compare to what you have now with this vendor you're using?"
- "Back when you chose to work with that company, what were your selection criteria? In what ways has that possibly changed as you look at your situation today, though?"
- "Can I ask in what ways your vendor could do better for you than what they are doing now, though?"
- "So, to me, it sounds like things are 100% PERFECT with what you're using now; what would you change if you could?"

**Reopening a Lost Deal:**
```
[Prospect chose another company/decided not to buy]
"Can I ask you something?"
"How can I communicate to you… that you might be making a mistake… without you getting upset with me?"
```

---

#### 2D: CONSEQUENCE QUESTIONS
**Purpose:** Get the prospect to think about what happens if they do NOTHING. Build urgency. Rip away the future state you just showed them. Get them to defend why changing NOW is important.

**Tone:** Use a challenging but concerned tone. Be tougher here — they need to feel the pain of inaction.

**Generic Consequence Questions:**
```
"What if you don't do anything about this problem [repeat problem], and your situation gets even worse?" (challenging tone)

"What are you going to do if nothing changes, if you keep using/doing [current approach] for the next [3/6/12 months / 5/10 years], and nothing changes?"

"Have you thought about what would happen if you don't do anything about this?"

"Have you considered the possible ramifications if you don't do anything about this...?"

"Do you want to [negative outcome] if you… if you didn't have to?"

"Okay, but on the flip side… What happens if you just keep the same [plan/vendor/approach]… and [negative consequence]… what happens to your [business/family/situation] at that point?"

"Why look at doing this now? Why not push it down the road like a lot of [people/companies] who [negative consequence]?"
```

**After They Respond Negatively:**
```
"Okay, so it's important for you to do something then?"
"Do you want to have to go through all of that… if you… if you didn't have to?"
"Are you willing to settle for that, though? Whose choice is it if you settle or not?"
```

**Expanded Consequence Questions (B2B):**
- "If you don't decide to address this problem now... how much will it cost you this year… in lost profit/revenue/sales?"
- "What would the impact be if your company decides to do nothing about solving [problem] and you stay with your current vendor?"
- "What's the potential impact on your business if you don't do anything about this? Are you willing to settle for that? Can your company achieve its goals without solving this issue?"
- "What type of effects will this have on your business... if you don't do anything about this?"

---

### STAGE 3: TRANSITION STAGE

**Purpose:** Bridge from the engagement to the presentation. Simple formula:

```
"Because you know how you said… [repeat back what they said they wanted]…
And because of that, it's making you feel… [repeat back the emotion: stressed, frustrated, worried]…

Based on what you told me… What we are doing could/would actually work for you…"
```

Then use one of:
- **One-call close:** "With your permission, I can go over a few things that we would be able to do for you to help you with your situation and solve those problems [repeat the actual problems]. Would that help you?"
- **Two-call / Demo:** "Good first call; that gives me more understanding of your situation and the challenges you guys are going through compared to where you want to be… Really, the next step would be to book another call to go over a demo [or proposal]. Would that help you?"

---

### STAGE 4: PRESENTATION STAGE (10% of the conversation)

**Purpose:** Demonstrate how your solution solves THEIR specific problems. Never cookie-cutter. Never present things they didn't tell you mattered.

**3-Step Presentation Formula:**
```
STEP 1:
"One of the biggest problems that people have when they come to us is they [repeat their main issue/challenge]…
Which causes them to… [consequences]"

STEP 2:
"So the way we solve that for our clients like you is we… [how your product/service solves this part of the problem]"

STEP 3:
"And what that means to you is… [repeat back the advantages and benefits of what it will do for them once solved]"
```

**Rules for Presentation:**
1. ONLY present around the problems/issues the prospect mentioned during the Engagement Stage
2. Customize every presentation — never use cookie-cutter decks
3. Use case studies: show a client with the same problems, your solution, the quantified results
4. Ask **8–12 Checking for Agreement Questions** throughout:
   - "Does that make sense?"
   - "Are we on the same page?"
   - "What are your thoughts on that?"
   - "Are you with me on this?"
   - "Do you see how that works?"
   - "Do you see how that could help you?"
   - "Any questions about that?"
   - "Is there anything else I should add?"
   - "How do you see that helping you the most?"

**Proposal Rules:**
1. Never give a proposal without understanding their problems AND confirming they have funds to solve them
2. If they ask for a proposal prematurely: "Yea, for sure, I'd be open to putting together a proposal for you, but just so you know, I'm not quite sure we could even help you yet. It might be better for you if we ask a few questions about what your situation is, and then we can put something together for you that might be more useful. Would it help you if we did that for you?"
3. Every proposal should include: their 2–3 key problems, their 2–3 key objectives, the value of solving those problems (must be at minimum 10x the cost), and **3 pricing options** (basic/core/premium)
4. Make the proposal signable as an agreement to reduce steps

---

### STAGE 5: COMMITMENT STAGE (5% of the conversation)

**Purpose:** Help the prospect commit and take the next step toward purchasing.

**Commitment Questions — In Action:**
```
"Do you feel like this could be the… answer for you?"
→ "Why do you feel it would, though?"

"What specific parts/aspects of what we went over today do you feel... are going to really help you the most?"

"Do you feel like this is something you can have/do that will get you where you want to go?"

[After YES:]
"Well, it looks like we covered what you're possibly looking for in [X].
Really, the next step is we would make some type of arrangement for you [next steps], 
you can use a credit or debit card, invoice, wire transfer, then at that point we would [action] so that you can [end result].
Would that be appropriate, or how… would you like to proceed from here?"
```

**Introducing Funds/Price:**
```
"So we pretty much covered how we could help you get to [XYZ result]; before we go into the funds/funding, do you feel… like this could be the answer for you?"
→ "Why do you feel it would, though?"
→ "Any questions on how that works?"
→ "Okay, really, the next step would be…"
→ "So write this down: the funding you will need for us to come in and solve [problems] to get you to [result] would be... [price]"
```

---

## Objection Handling

### "I need to think it over" / "I need to do more research"
- This happens because you didn't build enough of a GAP in the Engagement Stage
- Prevention: Strong Consequence Questions eliminate this objection before it surfaces

### "Send me a proposal/quote" (early in conversation)
```
"Awww.. I understand. Now, it might make sense FOR YOU… before I sent a proposal if I understood a little bit more about who you're using for [X] just to see if we could even help… because you might not even need us.
For example, what type of…" [→ transition to Situation Questions]
```

### "Send information to my email"
```
"Yea, I can do that for sure, now, just so I can put together the right information for you. What exactly are you looking for?"
→ "Okay, and who/what do you use now for your…?" [→ Situation Questions]
```
After engagement, close loop: "What I can do is send you the info about how we could solve [problems]. Now, let's suppose you go through it and see if it fits — what would you want the next step to be?"

### "Can you send references?"
```
"Yea, I can do that for sure… Now, just so I can send the right people to you, what specifically would you like to discuss with them?"
→ [Whatever they say = their real concern]
→ "I can reach out to them to see if that would work for their schedule… Now, let's pretend for a moment that the clients you talk to say good things about how we were able to solve the same type of problems you're having… where do you feel we should go from there?"
```

### "I'm too busy, call me back"
```
"That's not a problem. What I can do if it helps you… I will give you my number, and you'll have to call me back later today to see if I would be available for you. Would that help?
My number is [XXX]. What's your timeframe on getting back to me today, just to see if I would even be in the office for you?"
```
OR use **NEPQ Calendar Commitment:**
```
"Well, possibly it might be harder to randomly get a hold of me with my schedule. Here's what I can do, though: If you have your calendar handy, I could pull out mine so you can book a specific time with me; that way, you don't have to chase me down and vice versa… Would that work for you?"
```

### No Money / Budget / Funds
```
"Tell me, if you did have the funding/budget/money, is this something that would work for you?"
[If yes:]
"I can appreciate that money might be an issue based on what you told me. How do you think you can resolve that… so you can find the funding/funds so that you can...?" [Repeat back what they want]

"What other avenues do you have to find the funds/funding/money so that you can...?"

"Can I make a suggestion? What I can do is show you the other avenues our clients used to find the funds if they didn't have the funds themselves, and you will have to see if you have those avenues if you want to… [repeat back what they said they wanted]"
→ Then list funding options: 401k, bank loan, home equity, credit cards, company budget reallocation, etc.
"Which of those avenues do you have so that you can solve this problem and [repeat what they wanted]?"
```

### Cost is the Most Important Thing to Them
```
"You mentioned that the most important thing to you is cost… Can I ask how that compares to you actually getting results and being able to solve this problem, though?"
```

---

## Decision-Making & B2B Navigation

### Who Are the Decision Makers?
```
"Can you walk me through your company's decision-making process when it comes to solving problems like this?"

"Who else besides you would be involved in approving the funding/budget to solve this?"

"How will you get financial approval from the company to solve this [issue] you have talked about?"

"What obstacles would you possibly encounter when trying to get financial approval to solve [problem]?"
```

### Competitor / Vendor Comparison
```
"Let's suppose you meet with all these other companies, and let's say they all meet your criteria… can solve the same problems like we can… and the pricing is somewhat similar…
How would you then decide who to go with at that point?"
[Whatever they say = what you need to win the sale]
```

### Qualifying for In-Person Meetings
```
[Prospect asks for in-person demo:]
"Let's suppose I do come out to your office for a day. You're able to pull the owners and the other decision-makers together for me to do a demo in person, and everyone finds that we can solve the [problems] you mentioned like we do for our other clients. What do you see happening next?"
```
**Only travel/commit if they say:** "We would do business with you for sure."
**Do NOT commit if they say:** "We'd need to run it by the committee," "Compare it to current vendor," "Not sure what would happen."

---

## Key Tactics & Techniques

- **Verbal Pauses ("…"):** Intentional slowing down that causes prospects to think deeper and emotionally open up. Never rush through questions.
- **Tonality:** The most important element. Ranges from curious/soft → concerned → skeptical → challenging. Match tone to question type.
- **"Might," "Possibly," "Maybe":** Softeners that reduce resistance throughout the call
- **Mismatching:** Downplay the value slightly to make the prospect inflate it in their own mind. *"It's not gonna be much, but… around 10-11k over the next 10 years."* — causes them to make it a bigger deal
- **The Two Truths:** *"To me, it sounds like things are 100% PERFECT. What would you change?"* — forces them to identify dissatisfaction
- **Results-Based vs. Price-Based Thinking:** Pivot cost-focused prospects: *"Can I ask how that compares to you actually getting results?"*
- **Referral Scripts:** Never assume a referral is interested. Start with: *"Hi, I'm [name]. [Referrer] suggested I call you, as I recently helped them with [X]... she mentioned you might be experiencing the same challenges. Is this an appropriate time to talk?"*

---

## Language & Scripts — Master Reference

### Opening (Cold Call)
- *"Hey [Name], this is just [Your Name]. I was wondering if you could… help me out for a moment?"*
- *"I'm not quite sure who I should be talking to; I called to see who would be responsible for looking at any possible hidden gaps in your [area]…"*

### Opening (Outbound Lead)
- *"It looks like you recently responded to an ad on [platform] and asked us to call you back… Have you found what you're looking for, or are you still looking for [end result]?"*

### Status Frame (every call)
- *"This call is pretty basic; it's really more for us to find out about what you're using now, what results you're getting, compared to what you might be wanting, to see what that GAP looks like… And towards the end, if you feel like it might be what you're looking for, we can talk about possible next steps. Would that help you?"*

### Problem Discovery
- *"So, to me, it sounds like things are going 100% perfect for you. What would you change if you could?"*
- *"You don't sound so sure about it… what don't you like?"*
- *"Has that… has that had an impact on you?"* (verbal pace)
- *"Why is that important to you NOW, though?"*
- *"What if you don't do anything about this?"* (challenging tone)

### Future State
- *"How would it be different, though? You being able to [end result]. How would your life be… maybe different than it is now?"*
- *"What would that do for you personally, though?"*
- *"How would that make you… feel though?"*

### Commitment
- *"Do you feel like this could be the… answer for you?"*
- *"Why do you feel it would, though?"*
- *"What specific parts of what we went over do you feel are really going to help you the most?"*
- *"Would that be appropriate, or how… would you like to proceed from here?"*

### Reopening Deals
- *"Can I ask you something?"*
- *"How can I communicate to you… that you might be making a mistake… without you getting upset with me?"*

### Asking for Referrals
- *"Can I ask you... in your mind, how do you feel we've been able to help you the most?"*
- *"With that in mind, who do you know that might be struggling with [problem]?"*
- *"Can you tell me a little bit more about this person and why you feel I could help them, though?"*

---

## What to Avoid

- **Never pitch or tell** early in the conversation — "Telling is far less persuasive"
- **Never assume** the prospect knows what they need or that they're interested
- **Never ask "Are you the decision maker?"** — ask about the process instead
- **Never send a proposal** before understanding their problems AND confirming they have funding
- **Never send a proposal/info cold** without getting a commitment on next steps first
- **Never assume a referral is automatically interested** — approach them as cold
- **Never use "budget"** (limited-based thinking) — use "funds" or "funding" instead
- **Never do cookie-cutter presentations** — customize every one to their stated problems
- **Never present for more than 10–15%** of the conversation
- **Never ask about budget early** — they don't know what their real problems cost yet
- **Never say "you might be a good fit for us"** — creates resistance, sounds like a sales tactic
- **Never rush through questions** — verbal pauses are critical to emotional opening
- **Never argue with an upset customer** — ask questions; you want to win the relationship, not the argument

---

## Quick Reference: NEPQ Question Categories

| Question Type | Purpose | When to Use |
|--------------|---------|-------------|
| Connection Questions | Disarm, create curiosity | First 7–12 seconds of every call |
| Situation Questions | Understand current state | Stage 2, after connection; 3–4 questions |
| Problem Awareness | Find real problems + root causes | Stage 2; build the GAP |
| Solution Awareness | Attach emotionally to solving it | Stage 2, after problem awareness |
| Consequence Questions | Create urgency via inaction fear | Stage 2, after solution awareness |
| Transition Questions | Bridge to presentation | Stage 3 |
| Checking for Agreement | Keep engagement during presentation | Throughout Stage 4 (8–12x) |
| Commitment Questions | Close the deal | Stage 5 |
| Qualifying Questions | Test urgency and seriousness | Before travel, major investment of time |
| Decision-Making Questions | Map the org chart, find all influencers | B2B, before proposal |
| Funding/Budget Questions | Understand investment capacity | After problems established |
| Probing/Precision Questions | Deepen emotional pain, get specifics | Whenever prospects give vague answers |
| Resolving Questions | Handle complaints without arguing | Customer service / retention |
| Retention Questions | Monitor relationship health | Existing clients |

---

## Changelog
- 2026-03-22: Initial SOP created from *NEPQ Black Book of Questions* by Jeremy Miner (7th Level Inc.)
