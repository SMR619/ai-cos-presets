# SOP: AI Agent + CRM + Email Sync (The "Always-Updated Loop")

**Source:** Solutions Playbook Module #28
**Purpose:** Connect the agent's email account to GoHighLevel so all communications auto-log to contact records. Pair with a deal pipeline + webhook so the agent's memory files stay current without manual updates.
**When to use:** During onboarding, after email infrastructure is set up and GHL is confirmed.
**Prerequisites:** Agent email connected (see `sop-email-infrastructure.md`), GHL sub-account exists for the business.

---

## Why This Matters

Without this loop:
- The CRM goes stale — emails happen outside it
- The agent wastes tokens re-reading old emails to find history
- Deal stages live in markdown files that require manual updates
- Nothing is reliably current

With this loop:
- Every email auto-logs to the matching contact record in GHL
- Deal stages update automatically when things move
- Agent memory files sync without the agent having to remember to update them
- The CRM becomes the live source of truth — not a document that lags behind

---

## The Three Components

### Component 1 — Email ↔ GHL Sync (Two-Way)

**What it does:** Every email sent from or received at the agent's email address auto-logs to the matching contact's conversation timeline in GHL.

**Setup:**
1. In GHL → Settings → Email Services → Connect Mailbox
2. Connect the agent's email account (Microsoft 365 / Outlook recommended)
3. GHL matches emails to contacts by email address automatically

**Result:** The agent can check GHL to see full email history instead of scanning the inbox — saves tokens, prevents duplicate outreach, keeps contact records complete.

---

### Component 2 — Deal Pipeline in GHL Opportunities

**What it does:** Creates a structured pipeline where deals move through defined stages. The agent manages deal stages in real time, making GHL the live source of truth.

**Setup:**
1. In GHL → Opportunities → Pipelines → Create New Pipeline
2. Define stages matching the business's deal flow. Examples:
   - *Real estate:* Intake → Gathering Info → Submitted → Term Sheet → Closed / Dead
   - *Sales:* New Lead → Contacted → Proposal Sent → Negotiating → Won / Lost
   - *Consulting:* Inquiry → Discovery Call → Proposal → Onboarded / Declined
3. Add custom fields relevant to the business (deal size, key dates, notes)
4. Create contact tags relevant to that business's contacts (buyer, lender, lead, client, etc.)

**Result:** The agent moves deals through stages as they progress — GHL is always current.

---

### Component 3 — Webhook → Agent Memory Sync

**What it does:** When a deal moves stages in GHL, a webhook fires to the agent's endpoint. The agent automatically updates its deal files and memory — no manual logging required.

**Setup:**
1. In GHL → Settings → Webhooks → Add Webhook
2. Trigger: Opportunity Stage Changed
3. Endpoint: [your agent's webhook URL — set up in OpenClaw or n8n]
4. Agent receives the payload and updates relevant `projects/[name]/STATUS.md` or deal files

**Result:** Files stay current automatically. The agent never has stale deal data.

---

## Deployment Checklist (Per Business)

- [ ] Agent has a business email address (M365/Outlook or Gmail) — see `sop-email-infrastructure.md`
- [ ] GHL sub-account exists for this business
- [ ] Connect mailbox in GHL → Settings → Email Services
- [ ] Build pipeline + stages + custom fields in GHL → Opportunities
- [ ] Create relevant contact tags
- [ ] Set up webhook: Opportunity Stage Changed → agent endpoint
- [ ] Test: send an email, confirm it appears in GHL contact timeline
- [ ] Test: move a deal stage, confirm agent memory file updates
- [ ] Log configuration in MEMORY.md

---

## MEMORY.md Entry (After Setup)

```
## GHL Integration — [Business Name]
- GHL sub-account: [account name]
- Mailbox connected: ✅ / ❌
- Pipeline: [pipeline name] — [X stages]
- Webhook: ✅ / ❌ (Opportunity Stage Changed → [endpoint])
- Agent email: [address]
- Status: active ✅
```

---

## Why This Is Reusable

This pattern applies to every business where the agent handles email and deals:
- Real estate: lender communications, deal tracking
- Media/consulting: client outreach, contract pipeline
- Political: campaign contacts, vendor pipeline
- Any B2B business with a defined sales process

The components are the same. Only the pipeline stages and tags change.

---

**Tools:** Microsoft 365 / Outlook (Graph API) or Gmail, GoHighLevel (CRM, pipeline, webhooks), OpenClaw (agent runtime)
**Cost:** Included in existing GHL subscription + email license
