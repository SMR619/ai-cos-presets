# Traction / EOS (Entrepreneurial Operating System) — SOP
**Source:** *Traction: Get a Grip on Your Business* by Gino Wickman
**Domain:** Operations, Leadership, Strategy
**Last Updated:** 2026-03-22

## Core Philosophy
The Entrepreneurial Operating System (EOS) is a complete set of tools for running a business built around six key components: Vision, People, Data, Issues, Process, and Traction. Most small business chaos comes from one or more of these components being weak. The cure is not more ideas or more effort — it's strengthening each component above 80%. "Vision without traction is merely hallucination." Ideas without execution are worthless; execution without vision is busywork. EOS creates a 90-Day World where the entire team stays focused, accountable, and aligned.

## Key Frameworks

### 1. The Six Key Components of EOS
Every successful business, consciously or not, masters all six:

| Component | Focus | Core Tool |
|---|---|---|
| **Vision** | Where are we going and how will we get there? | V/TO (Vision/Traction Organizer) |
| **People** | Do we have the right people in the right seats? | People Analyzer + Accountability Chart |
| **Data** | Are we running the business on objective numbers? | Scorecard |
| **Issues** | Can we identify and solve problems quickly? | Issues Solving Track (IDS) |
| **Process** | Is the way we do business documented and followed? | Core Process Documentation |
| **Traction** | Does everyone stay accountable and execute? | Rocks + Meeting Pulse |

### 2. The Vision/Traction Organizer (V/TO)
A 2-page document answering 8 questions. Page 1 = Vision. Page 2 = Traction. This IS the business plan.

**The 8 Questions:**
1. What are your Core Values? (3-7)
2. What is your Core Focus? (Purpose/Cause/Passion + Niche)
3. What is your 10-Year Target? (BHAG)
4. What is your Marketing Strategy? (Target market, 3 Uniques, Proven Process, Guarantee)
5. What is your 3-Year Picture? (Revenue, profit, measurables, 10-20 bullets)
6. What is your 1-Year Plan? (Revenue, profit, 3-7 goals)
7. What are your Quarterly Rocks? (3-7 priorities for next 90 days)
8. What are your Issues? (All obstacles and opportunities)

### 3. The People Analyzer
Rate every person against every core value: **+** (exhibits most of the time) / **+/−** (sometimes) / **−** (doesn't exhibit most of the time).

Minimum bar (example for 5 values): 3 pluses, 2 plus/minuses, zero minuses.

### 4. GWC — Right Seat Filter
Every person in every role must:
- **G**et it — truly understand the role
- **W**ant it — genuinely like the job
- **C**apacity to do it — have the time, mental, physical, emotional capacity
All three must be YES. One NO = wrong seat.

### 5. Rocks (90-Day Priorities)
The 3-7 most important things that must get done in the next 90 days. Not everything — the most important things. "When everything is important, nothing is important."

### 6. The Level 10 Meeting (Weekly L10)
A 90-minute weekly meeting with a strict agenda designed to solve problems, not just report status. Named "Level 10" because the goal is to rate every meeting a 10/10 for productivity.

### 7. Issues Solving Track (IDS)
**Identify** the real root cause → **Discuss** (everyone says their piece, once) → **Solve** (create a to-do or decision). Most stated problems are symptoms; the real issue is usually a people problem.

### 8. The Meeting Pulse
Annual planning (2 days, off-site) → Quarterly planning (1 day, off-site) → Weekly L10 (90 min). Like an EKG — regular spikes of productivity and alignment. Skipping a meeting = falling back into chaos.

---

## Step-by-Step Process

### Setting Up Vision (V/TO)

#### Discover Core Values (4 Steps)
1. Each leadership team member names 3 people in the company who, if cloned, would lead to market domination
2. List all characteristics those people embody on a whiteboard
3. First edit: circle truly important ones, cross out non-essentials, combine similar. Target 5-15.
4. Through group discussion, narrow to **3-7 truly core values**
5. Let them simmer 30 days, then finalize
6. For each value, write 3-5 supporting bullet points (stories, examples, what it looks like in practice)

#### Set Core Focus
- **Purpose/Cause/Passion**: 3-7 words. Simple. Big. From the heart. Test: Can you tell what industry you're in from it? (You shouldn't be able to.)
- **Niche**: The one thing you do better than anyone. Simple filtering mechanism for all decisions.

#### Set 10-Year Target
- Single, specific, measurable, bold goal
- Must create passion and energy
- When 3 years away from achieving it, move it to the 3-Year Picture and set a new one

#### Define Marketing Strategy (4 Parts)
1. **Target Market**: Define ideal customer by demographics, geographics, psychographics. Create a list of all perfect prospects.
2. **Three Uniques**: What makes you different? No competitor should have all three. Must be honest and defensible.
3. **Proven Process**: Your delivery method visualized on one page. 3-7 named steps with bullet points. Give it a name. Have it professionally designed.
4. **Guarantee**: Pinpoint an industry-wide frustration and solve it. Must drive business or help close deals. Don't force a bad one.

#### Build 3-Year Picture
- Set a future date 3 years out
- Set revenue, profit, and 1-2 measurables showing scope
- Write 10-20 bullet points describing what the organization looks like then
- Read it aloud to leadership team — everyone should be able to see it clearly

#### Build 1-Year Plan
- Revenue goal, profit goal, measurable
- 3-7 goals that are specific, measurable, attainable
- Must be supported by a projected budget

### Building the Accountability Chart
1. Start with three major functions: Sales/Marketing, Operations, Finance/Admin
2. Identify who is the Integrator (runs the company day-to-day)
3. Identify if there is a Visionary (typically founder)
4. Build out each function with 5 major roles per function
5. **One person per seat** — two names in one seat is never okay
6. Write Position Contracts for each seat (results, roles, accountabilities)
7. Test each seat with GWC: Get it, Want it, Capacity?

### Running the People Analyzer
1. Leadership team people-analyzes each other first (builds trust, validates the tool)
2. Rate everyone in the company on a People Analyzer grid
3. Managers share results one-on-one with their direct reports
4. Use in quarterly performance reviews
5. For any personnel concern, run the person through the analyzer before deciding

### Building and Running the Scorecard
1. Identify 5-15 activity-based numbers that predict the health of the business
2. Assign one person accountable for each number
3. Set the weekly goal for each
4. Review every week in the L10 meeting
5. Red-flag anything off-track; drop to IDS
6. After 13 weeks, patterns emerge

### Documenting Core Processes (3 Stages)
**Stage 1: Identify**
- Leadership team agrees on the name of each core process (typically 6-8)
- Standard list: HR, Marketing, Sales, Operations (1-3), Accounting, Customer Retention

**Stage 2: Document**
- The accountable person per the Accountability Chart documents their process
- Follow the 20/80 rule: document the 20% that produces 80% of results
- 2-10 pages per process, max
- High-level steps with bullet-point procedures; add checklists where possible

**Stage 3: Package and Follow**
- Compile all processes into "[Company Name] Way" binder or intranet
- Hold company meeting to share and train on the Way
- Retrain everyone
- Manage to the process — leadership must follow it too

### Setting Quarterly Rocks (8 Steps)
1. Review V/TO; list everything that must be accomplished this quarter (10-20 items)
2. Discuss, debate, prioritize — narrow to 3-7 company Rocks
3. Set due date (end of quarter: March 31, June 30, Sept 30, Dec 31). Make each Rock specific and measurable.
4. Assign ONE owner per Rock
5. Each leadership team member sets their individual Rocks (3-7 each)
6. Create Rock Sheet — company Rocks at top, individual below. NO new priorities mid-quarter.
7. Share company Rocks with entire organization at state-of-the-company meeting
8. Each department sets their Rocks (1-3 per employee)

### Running the Level 10 Weekly Meeting (90 min)

| Segment | Time | What Happens |
|---|---|---|
| **Segue** | 5 min | Share one good news (personal or business). Devices off. |
| **Scorecard Review** | 5 min | Review numbers; off-track items → IDS. No discussion here. |
| **Rock Review** | 5 min | "On track" or "off track" per Rock. Off-track → IDS. No discussion. |
| **Customer/Employee Headlines** | 5 min | Short headlines, good or bad. Issues → IDS. |
| **To-Do List Review** | 5 min | "Done" or "not done." 90% should clear weekly. |
| **IDS (Issues Solving Track)** | 60 min | Prioritize top 3, then IDS each: Identify → Discuss → Solve |
| **Conclude** | 5 min | Review to-dos created, cascading messages to communicate, rate meeting 1-10. |

**Rules:**
- Same day, same time, same place, every week — no exceptions
- Meeting starts on time whether everyone is there or not
- One person runs the meeting (moves through agenda)
- One person manages the Issues/To-Do lists
- No discussion during Scorecard, Rock Review, or Headlines — drop to IDS

### Quarterly Off-Site Planning Day (8 Hours)
1. **Segue**: Best news, what's working/not working, expectations
2. **Previous Quarter Review**: Numbers and Rocks — "done" or "not done." Target 80%+ completion.
3. **V/TO Review**: Refresh, update Issues List
4. **Establish Next Quarter Rocks**: Follow the 8-step Rock process
5. **IDS**: Tackle remaining key issues in priority order
6. **Next Steps**: Who does what; messages to cascade to organization
7. **Conclude**: Feedback, rate the day 1-10

### Annual Planning (2 Days, Off-Site)

**Day 1:**
1. Segue: Three greatest company accomplishments, personal greatest accomplishment
2. Review previous year: Goals (done/not done), numbers, last quarter Rocks
3. Team health: "One Thing" exercise — each person gets open feedback from peers (greatest strength, biggest weakness; commit to one change)
4. SWOT + Issues List development
5. V/TO through 1-Year Plan: Challenge every element, rebuild 3-Year Picture, set new 1-Year Plan

**Day 2:**
1. Establish next quarter's Rocks
2. IDS key issues
3. Next steps
4. Conclude (team dinner together end of Day 1)

---

## Key Tactics & Techniques

- **"People need to hear the vision 7 times before they really hear it."** Don't get frustrated by repetition — build it into your communication cadence.
- **The 36 Hours of Pain Rule**: Letting someone go is painful for ~36 hours. After that, relief — and other employees will wonder what took so long. Don't delay necessary personnel moves.
- **"As goes the leadership team, so goes the company."** Fix leadership first, everything else follows.
- **One voice, one system**: You can't implement multiple operating systems at once. Commit fully to EOS or it won't work.
- **The buildup effect of scheduled meetings**: When a full-day quarterly meeting is scheduled weeks in advance, people unconsciously prepare. Energy and clarity build toward it. Never skip or call impromptu full-day meetings.
- **Activity-based Scorecard numbers**: Lag indicators (profit, revenue) tell you what happened. Lead indicators (calls made, proposals sent) tell you what WILL happen. Build your Scorecard on leads, not lags.
- **Everyone has a number**: Every employee should have at least one measurable number tied to their role. It creates clarity, accountability, and motivation.
- **The 20/80 Process Rule**: Don't document everything. Document the 20% of steps that drive 80% of the result. A 2-page process is followed; a 200-page process is ignored.
- **No new priorities mid-quarter**: Once Rocks are set, the wall goes up. New ideas go on the V/TO Issues List for next quarter. This is the discipline that creates traction.
- **IDS order**: Always solve the highest-priority issue first. Solving the root cause often eliminates several other "issues" that were actually symptoms.

---

## Language & Scripts

**Core V/TO phrases:**
> *"Vision without traction is merely hallucination."*

> *"When everything is important, nothing is important."*

> *"He who chases two rabbits catches neither."*

**On People:**
> *"Get the right people in the right seats."*

> *"Right person = shares your core values. Right seat = GWC: they Get it, Want it, and have the Capacity to do it."*

**On vision communication:**
> *"People need to hear the vision seven times before they really hear it for the first time. So stop saying 'I've told them three times — this is so frustrating!' and start saying 'I've told them three times — only four more to go!'"*

**On personnel decisions:**
> *"The 36 Hours of Pain: It's going to hurt. But it will hurt for about 36 hours. After that, you'll feel relief. And your other employees will thank you and wonder what took you so long."*

**On process:**
> *"Get it out of your head and onto paper. The business must be able to run without you."*

**On meetings:**
> *"Well-run meetings are the moment of truth for accountability."*

**On issues:**
> *"Your ability to succeed is in direct proportion to your ability to solve your problems."*

**Diagnosing a bad meeting (IDS rule):**
> *"Identify the real issue — what we're discussing is probably a symptom. Say it once. Then solve it."*

**Rock-setting filter:**
> *"If this Rock is done by March 31, will we be materially closer to our 1-Year Plan? If not, it's not a Rock."*

**GWC check:**
> *"Does [person] Get it? Do they Want it? Do they have the Capacity to do it? All three must be yes. One no = wrong seat."*

---

## What to Avoid

- **Implementing EOS half-heartedly**: You can't run two operating systems. Partial commitment = zero benefit.
- **Skipping quarterly off-sites**: Without quarterly resets, teams drift back to chaos within 90 days — like clockwork.
- **More than 7 Rocks**: Rocks lose meaning when there are too many. Force prioritization.
- **Adding Rocks mid-quarter**: The wall must go up. New priorities destroy the 90-Day World and erode accountability.
- **Discussing in Scorecard/Rock Review segments**: Those are reporting segments. Discussion happens only in IDS.
- **Two people in one seat**: Shared accountability = no accountability.
- **Documenting every step in process**: 500-page manuals are never followed. 20/80 — capture the key steps, not every micro-action.
- **Solving symptoms instead of root causes**: Most issues trace back to a people problem. Ask "why?" three times before deciding you've found the real issue.
- **Protecting underperformers too long**: Every day a wrong person stays in a seat costs you time, money, morale, and a seat that a right person could fill.
- **Rating Rocks "mostly done"**: Rocks are binary — "done" or "not done." This is the accountability discipline. No partial credit.

---

## Application to Your Businesses

### [BUSINESS NAME] (Service / B2B Example)
- **V/TO is the starting point**: [OWNER NAME] needs a clear 10-Year Target and 3-Year Picture for the business — what does it look like at scale?
- **Accountability Chart**: Define the Visionary ([OWNER NAME]) and Integrator (who runs day-to-day?). If there's no Integrator, [OWNER NAME] is wearing both hats and hitting a ceiling.
- **Three Uniques**: What are the 3 things that make this business different from any competitor? These must be real, defensible, and consistent across all marketing.
- **Proven Process**: Visualize the delivery process on one page. Client onboarding → discovery → delivery → reporting → optimization. Name it.
- **Scorecard**: Weekly numbers — proposals sent, clients onboarded, projects live, reports delivered, retention rate.
- **Quarterly Rocks**: Pick the 3-7 most important things to move the business forward this quarter. Systems? New client acquisition? Team building?

### [BUSINESS NAME] (Real Estate / Deal-Based Example)
- **Core Process Documentation**: Document the acquisition process, seller conversation flow, deal underwriting, and funding/closing sequence. Get it out of [OWNER NAME]'s head and onto paper.
- **Rocks for deal volume**: Set quarterly Rocks for deal acquisition numbers, community engagement targets, capital partner relationships.
- **Accountability for deals**: Who owns each deal? Who is accountable for each stage? Accountability Chart even for a small operation.

### [BUSINESS NAME] (Home Services / Local Business Example)
- **Operations Core Process**: Document the installation/service process, project flow, and maintenance protocol. This becomes the "[Business Name] Way."
- **Scorecard numbers**: Calls/week, quotes/week, jobs/week, average ticket, referrals generated.
- **People Analyzer**: Run every current team member through the People Analyzer to verify right people in right seats.

### [PARTNER NAME]'s Side Projects (Content / Creator Example)
- **Proven Process for content**: Script → record → edit → publish → promote. Document it. Make it followable by someone else.
- **Rocks for channel/project growth**: Specific, measurable quarterly goals (e.g., publish X pieces, reach Y milestone).

---

## Changelog
- 2026-03-22: Initial SOP created from *Traction* by Gino Wickman (EOS framework)
