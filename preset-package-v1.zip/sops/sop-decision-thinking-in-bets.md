# Thinking in Bets — SOP
**Source:** *Thinking in Bets: Making Smarter Decisions When You Don't Have All the Facts* by Annie Duke
**Domain:** Decision-Making, Strategy, Leadership
**Last Updated:** 2026-03-22

## Core Philosophy
Every decision is a bet on an uncertain future — outcomes are shaped by both decision quality AND luck. The goal is not to be "right" or "wrong" but to make good decisions given available information, then learn accurately from results by separating skill from luck. Life is poker, not chess: hidden information, incomplete data, and chance are always in play. The better your decision process, the better your life over time.

## Key Frameworks

### 1. Life is Poker, Not Chess
Chess has perfect information and one correct move — real decisions don't. Poker is the better mental model: incomplete information, hidden factors, luck influences outcomes. You can make the best decision and still lose; you can make a terrible decision and get lucky. Stop judging decisions by outcomes alone.

### 2. Decisions as Bets (Belief → Bet → Outcome Set)
Every decision follows: **Belief → Bet → Set of Possible Outcomes**. You are always betting against all future versions of yourself you're NOT choosing. Map out possible futures, assign rough probabilities, choose the bet with the best expected value. We bet based on what we believe about the world — more accurate beliefs = better bets.

### 3. Resulting (The Core Trap to Avoid)
**Resulting** = equating decision quality with outcome quality. This is the #1 error. A bad outcome doesn't mean you made a bad decision. A good outcome doesn't mean you made a good decision. Judge decisions on process, not results.

### 4. Luck vs. Skill Sorting
For every outcome, ask: was this skill (I would get the same result making the same decision again) or luck (my decision didn't meaningfully impact the outcome)? Sort accurately. Self-serving bias makes us credit skill for wins and blame luck for losses — flip it deliberately to learn.

### 5. Belief Calibration
Instead of binary right/wrong beliefs, assign confidence levels (0–100%). Beliefs are probabilistic estimates, not fixed truths. Update them when new information arrives. The goal is calibration, not certainty.

### 6. Decision Pods (Group Accountability)
Form or join a small group focused on better decision-making. The group agrees to truthseeking norms: open-mindedness, credit where due, accountability for errors. Conditions for optimal group thinking: (a) audience views unknown upfront, (b) interested in accuracy, (c) reasonably well-informed, (d) has legitimate reason for inquiry.

### 7. Ideal Epistemic Community (4 Norms)
1. **Communism** — Data belong to the group, not individuals
2. **Universalism** — Apply uniform standards to all claims regardless of source
3. **Disinterestedness** — Watch for conflicts of interest
4. **Organised Skepticism** — Actively encourage dissent and challenge conventional wisdom

### 8. Mental Time Travel (10-10-10)
Before making a decision, ask:
- What are the consequences of each option in **10 minutes?**
- In **10 months?**
- In **10 years?**
Also run it backward: "How would I feel today if I'd made this decision 10 minutes/months/years ago?"

### 9. Backcasting vs. Premortem
- **Backcasting**: Imagine the desired outcome already happened. Headline: "We Achieved Our Goal!" Now reverse-engineer how you got there.
- **Premortem**: Imagine failure already happened. Headline: "We Failed To Reach Our Goal." Now identify all the ways it could go wrong. (Research shows this increases identification of failure reasons by 30%.)

### 10. Ulysses Contracts (Precommitment)
Lock in decisions in advance to remove temptation from future emotional states. Raise barriers against irrationality before the irrational moment arrives. Example: decide in advance exactly what evidence would cause you to change your position — and commit to it before you see the evidence.

---

## Step-by-Step Process

### Making a Decision

1. **Identify the decision** and what's at stake (time, money, relationships, opportunity cost)
2. **Map possible futures**: What are the realistic outcomes if I make each available choice?
3. **Assign rough probabilities**: Not 0% or 100% — what's your honest confidence level?
4. **Examine your beliefs**: Are they based on solid evidence or assumption? Would you bet money on them?
5. **Apply 10-10-10**: What are consequences at 10 min / 10 months / 10 years?
6. **Run a premortem**: Imagine it failed. What went wrong? Can you prevent it?
7. **Make the decision** and document your reasoning (not just the outcome)
8. **After outcome**: sort into luck vs. skill. What can you actually learn?

### Updating Beliefs

1. Hear new information
2. Resist the urge to confirm existing belief
3. Ask: "Would I bet money on my current belief being correct?"
4. Rate confidence (0–100%)
5. Identify what evidence would change your belief
6. Update based on evidence, not comfort

### Learning from Outcomes

1. Name the outcome (good or bad)
2. Ask the luck test: "Would I get this same outcome making this same decision again?"
3. Ask the skill test: "Would changing my decision have predictably changed the outcome?"
4. If skill-driven: what specifically caused the outcome?
5. Flip self-serving bias: if good, look for luck factors; if bad, look for your decision errors
6. Extract the actual lesson (or confirm there is none if it was luck)

---

## Key Tactics & Techniques

- **"Wanna Bet?" Test**: Before committing to a belief, ask: "Would I bet money on this?" This triggers more rigorous, less biased evaluation of your own certainty.
- **Confidence Rating on Everything**: Express beliefs with a confidence % (e.g., "I'm 75% sure of this") instead of binary certain/uncertain.
- **Imagine It Happened to Someone Else**: To de-bias evaluation, pretend the same outcome happened to another person. How would you judge it then?
- **Lead with Assent**: In feedback or disagreement, first explicitly name what you AGREE with, then add your perspective using "AND" not "BUT."
- **Disentangle Message from Messenger**: Evaluate information on its merits, not its source. Ask: if this came from someone I trust 100%, would I take it more seriously?
- **Give Details, Not Outcome**: When seeking advice on a past decision, share the context and details without revealing what happened. Prevents outcome-based bias in the advice you receive.
- **Red Team Everything Important**: Assign someone (or yourself) to argue against the decision you're leaning toward. Make this a standard practice for major decisions.
- **Decision Swear Jar**: Identify the words and patterns that signal irrational thinking for you personally. When you catch yourself using them, stop, pause, and think.
- **Poker Player's Forward Thinking**: Think beyond the current decision to subsequent ones — how does this decision affect future decision trees?

---

## Language & Scripts

**Expressing uncertainty without losing credibility:**
> *"I'm about 80% on this — not totally certain, but fairly confident."*

**Triggering honest belief evaluation:**
> *"Would you be willing to bet money on that?"*
> *"What odds would you give that?"*

**Asking for venting vs. advice clarity:**
> *"Are you looking to vent right now, or looking for advice?"*

**Leading with assent in disagreement:**
> *"I agree with [specific point]. And I think we should also consider..."* (not "but")

**Premortem framing:**
> *"Let's imagine it's one year from now and this failed completely. What happened?"*

**Backcasting framing:**
> *"It's one year from now and this worked exactly as hoped. How did we get here?"*

**Admitting uncertainty to invite collaboration:**
> *"I'm not fully sure on this — here's my current thinking at about 70%. What am I missing?"*

**Reframing a loss without blame:**
> *"Given what I knew at the time, was my decision reasonable? What new information do I now have that changes things?"*

---

## What to Avoid

- **Resulting**: Never judge the quality of a decision by its outcome alone — especially on a single data point
- **Binary Thinking**: Avoid "right/wrong" or "certain/uncertain" framing for beliefs — everything is a probability
- **Self-Serving Attribution**: Don't automatically credit skill for wins and blame luck for losses
- **Belief Anchoring**: Don't resist updating beliefs when new evidence arrives just because it's uncomfortable
- **Motivated Reasoning**: Don't seek information to confirm what you already believe — actively look for disconfirming evidence
- **Outcome Bias in Learning**: Don't change strategy just because of a bad outcome in a small sample — look at the decision quality, not the result
- **Consensus Over Truth**: Don't prioritize agreement in a decision pod over honest dissent — dissent is the point
- **Ignoring Opportunity Cost**: Every choice forecloses other choices. The cost of a decision includes what you DIDN'T choose.
- **Certainty Theater**: Projecting more confidence than you have to seem authoritative — it prevents learning and misleads others

---

## Application to Your Businesses

### [BUSINESS NAME] (Service / B2B Example)
- **Major decisions** (budget allocations, platform choices, client commitments) are bets — run backcasts and premortems before committing major spend
- When a campaign or project underperforms, explicitly sort: was it the strategy (skill) or market conditions/timing (luck)? Don't change winning processes based on one bad outcome
- Use confidence ratings when pitching clients: "Based on similar situations, I'd put this at 75% likely to hit the target range" — builds credibility through honesty

### [BUSINESS NAME] (Real Estate / Deal-Based Example)
- Every deal offer is a bet — assign probability to exit strategies before committing
- Use premortem for every deal: "This deal went sideways in 90 days — what happened?" before closing
- Document your decision rationale at the time — not just outcomes — to build a learning database

### [BUSINESS NAME] (Home Services / Local Business Example)
- Pricing and project bids are bets on time/material costs — rate your confidence in each estimate
- When bids are lost, sort luck vs. skill: was it price (skill — recalibrate), or was it a client who was never going to buy (luck)?

### [PARTNER NAME]'s Side Projects (Content / Creator Example)
- Content that performs well or poorly: sort luck vs. skill before changing strategy
- Apply 10-10-10 to content strategy decisions: what does the channel/project look like in 10 months if we stay this course?

---

## Changelog
- 2026-03-22: Initial SOP created from *Thinking in Bets* by Annie Duke
