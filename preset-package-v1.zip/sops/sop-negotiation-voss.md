# Never Split the Difference — SOP

**Source:** *Never Split the Difference* by Chris Voss (former FBI lead hostage negotiator)
**Domain:** Negotiation, Sales, Influence
**Last Updated:** 2026-03-22

---

## Core Philosophy

Humans are irrational, emotional creatures whose decisions are driven by System 1 (fast, emotional) thinking, not System 2 (slow, logical). Negotiation is not a battle of arguments — it is a **process of discovery**. The negotiator's job is to influence System 1 to guide System 2 decisions by achieving deep tactical empathy, not by deploying logic or grinding down resistance. Emotions are not obstacles — they are the primary means of negotiation.

---

## Key Frameworks

### 1. Tactical Empathy
Understanding the feelings and mindset of another **in the moment** — hearing what is behind those feelings to increase influence. Not sympathy (not agreeing with values or giving hugs). Bringing attention to both emotional obstacles and potential pathways to agreement. "Emotional intelligence on steroids."

### 2. Behavioral Change Stairway Model (BCSM)
Five stages that must happen in sequence:
1. Active Listening
2. Empathy
3. Rapport
4. Influence
5. Behavioral Change

You cannot skip stages. Rapport only comes after genuine empathy is established.

### 3. The Ackerman Bargaining Model
A disciplined price negotiation framework (see Step-by-Step Process section).

### 4. Black Swan Theory
Every negotiation contains at least three unknown unknowns ("Black Swans") per side — hidden pieces of information whose discovery changes everything. Your job is to find them. They are leverage multipliers.

### 5. Three Types of Leverage
- **Positive Leverage:** Your ability to provide or withhold what the counterpart wants (when they say "I want X," you have it)
- **Negative Leverage:** Your ability to make them suffer. Never shove it down their throat — label it subtly instead
- **Normative Leverage:** Using their own norms and standards against them; showing inconsistency between their stated beliefs and actions

### 6. Three Negotiator Types
- **Analyst:** Methodical, hates surprises, uses silence to think — use data, warn early, respect their process
- **Accommodator:** Relationship-first, warm, may agree to things they can't deliver — use "How" questions to pin down implementation
- **Assertive:** Time=money, must be heard before they can listen — use mirrors, labels, calibrated questions, push for "That's right"
- ⚠️ 66% chance your counterpart is a different type than you — never project your style

---

## Step-by-Step Process

### Opening a Negotiation
1. Prepare for surprises — hold all assumptions as **hypotheses to test**, not facts
2. Make your sole focus **the other person and what they have to say** (this calms your own inner voice and theirs)
3. **SLOW DOWN** — going too fast signals you don't care; people who feel rushed feel unheard
4. Use the **Positive/Playful voice** as your default (warm, easygoing, smiling — even on the phone)
5. Perform an **Accusation Audit** before major conversations — list every negative thing they could say about you and say it first

### Building Rapport & Understanding
6. Use **Mirroring** — repeat the last 1–3 critical words of what they said in an inquisitive tone; then go silent (4+ seconds); repeat
7. Use **Labeling** — detect their emotional state, then say: *"It seems like..."* / *"It sounds like..."* / *"It looks like..."* — then go silent
8. Label negative emotions to drain their power; label positive emotions to reinforce them
9. Push for **"That's Right"** — not "you're right" — by using summaries (paraphrase + label = "the world according to them")
10. Use **Minimal Encouragers** to keep them talking: "Yes," "OK," "Uh-huh," "I see"

### Creating Safety & Extracting Information
11. Trigger **"No"** early — it gives them safety and control. Use: *"Is now a bad time to talk?"* instead of *"Do you have a few minutes?"*
12. After hearing "No," ask: *"What about this doesn't work for you?"* / *"What would you need to make it work?"*
13. Use **Calibrated Questions** ("What" and "How" questions) to give counterpart illusion of control while gathering intelligence
14. Probe for Black Swans — hidden motivations, constraints, or needs not yet revealed

### Moving Toward Agreement
15. Aim for **"That's Right"** — a true epiphany moment where they feel genuinely understood and embrace the conclusion
16. Apply the **Rule of Three** — get the same commitment three times in one conversation (first agreement → label/summary → "How" implementation question)
17. Watch for fake buy-in: **"You're right"** = they want you to stop; **"I'll try"** = they plan to fail — both trigger more "How" questions
18. Verify alignment with the **7-38-55 Rule**: if tone/body language don't match words, label it: *"I heard you say yes, but it seemed like there was hesitation in your voice"*

### Bargaining (Ackerman Model — 6 Steps)
1. Set your **target price** (your actual goal)
2. Open at **65% of your target price** (extreme anchor — induces shock and resets their frame)
3. Plan three raises of **decreasing increments**: to 85% → 95% → 100% of target
4. Use empathy and different ways of saying "No" between each raise to force them to counter first
5. Final number: use a **precise, non-round number** (e.g., $37,893, not $38,000 — it feels calculated and final)
6. At your final number, **throw in a small, non-monetary item** they probably don't want (signals you've given everything)

### Closing & Implementation
19. Ask **"How" questions** to guarantee execution: *"How will we know we're on track?"* / *"How will we address things if we get off track?"*
20. Summarize agreed terms until you get "That's right" — then they own it
21. Never declare victory — keep the relationship intact

---

## Key Tactics & Techniques

- **Mirroring:** Repeat last 1–3 words in inquisitive tone → silence → let them elaborate. Works because we're biologically drawn to similarity. Waiters who mirror earn 70% more tips.

- **Labeling:** *"It seems like..."* / *"It sounds like..."* — NEVER start with "I" (e.g., never "I'm hearing that..."). Silence follows every label. Labeling moves fear from the amygdala to rational brain centers.

- **Accusation Audit:** List every negative thing they could say about you. Say them first — out loud. Accusations sound exaggerated when spoken, making them easy to dismiss. *"You're going to think I'm a lousy businessman..."*

- **Calibrated Questions:** "What" and "How" questions only. Remove aggression from statements by converting to questions. *"You can't leave"* → *"What do you hope to achieve by going?"*

- **The "No"-Oriented Email:** When ignored, send: *"Have you given up on this project?"* — triggers loss aversion and almost always generates a reply.

- **Fair Language:** Use proactively at the start: *"I want you to feel you're being treated fairly at all times. Please stop me if you feel I'm being unfair and we'll address it."*

- **"Why" as a Flip:** *"Why would you ever change from your existing supplier? They're great!"* — coaxes the counterpart into selling you on switching.

- **Pronoun Analysis (Detecting Liars/Power):** Liars use more words, more third-person pronouns, more complex sentences. More "I/me/my" = less important. Harder to extract first-person pronouns = more important/powerful person.

- **Anchoring via Range:** Instead of a single number, anchor with a range where the low end is your target: *"Top companies pay $130,000–$170,000 for this role."* Expect them to come in at the low end (which is still your goal).

- **The Non-Round Number:** End negotiations with odd, precise numbers ($37,263 vs. $38,000). Feels calculated, researched, and immovable.

- **The Surprise Gift:** After an extreme anchor and their rejection, offer a small, unrelated item. Triggers reciprocity.

- **Strategic Umbrage:** Channel genuine anger at the proposal, not the person: *"I don't see how that would ever work."* Must be genuine — fake anger backfires.

---

## Language & Scripts

### Opening / Rapport
- *"Is now a bad time to talk?"* (better than "do you have a minute?")
- *"I want you to feel you're being treated fairly at all times. Please stop me if you feel I'm being unfair."*

### Mirroring
- [Repeat last 1-3 words in a questioning, gentle tone]
- Then: silence for 4+ seconds

### Labeling
- *"It seems like..."*
- *"It sounds like..."*
- *"It looks like..."*
- Then: silence

### Accusation Audit
- *"You're going to think I'm a lousy businessman..."*
- *"You're going to think we are the big, bad prime contractor..."*
- *"I want to tell you in advance — this is going to be uncomfortable..."*

### Calibrated Questions
- *"What about this is important to you?"*
- *"How can I help to make this better for us?"*
- *"How would you like me to proceed?"*
- *"What is it that brought us into this situation?"*
- *"How can we solve this problem?"*
- *"What's the objective? / What are we trying to accomplish here?"*
- **The Greatest:** *"How am I supposed to do that?"* (said deferentially — buys time, creates forced empathy, says "No" without saying it)

### Saying "No" Four Times Before Actually Saying It
1. *"How am I supposed to do that?"* (deferentially)
2. *"Your offer is very generous. I'm sorry, that just doesn't work for me."*
3. *"I'm sorry, but I'm afraid I just can't do that."*
4. *"I'm sorry, no."* (gentle, with downward inflection)
5. (If needed): *"No."* (with downward inflection and tone of regard)

### Pushing for "That's Right"
- Label + Paraphrase: *"It all seems so tragically unfair, I can now see why you sound so angry."*
- Follow with silence — let them say "That's right"

### The "No"-Oriented Email (When Ignored)
- *"Have you given up on this project?"*

### Salary / Compensation Scripts
- *"At top places like [X Corp], people in this job get between $130,000 and $170,000."*
- *"Let's put price off to the side for a moment and talk about what would make this a good deal."*
- *"What else would you be able to offer to make that a good price for me?"*
- *"What does it take to be successful here?"* (recruits a mentor, sparks interest in your success)

### Ackerman Bargaining
- *"I'm sorry, I'm afraid I just can't pay any more than [65% offer]."*
- *"It's a beautiful [product]. It's worth more than what I'm offering. I'm sorry, this is really embarrassing. I just can't do that price."*
- Then: silence

### Fair Language (Weaponized)
- When accused: *"Fair?" [mirror]* → [pause] → *"It seems like you're ready to provide the evidence that supports that."*

### Implementation / Commitment
- *"How will we know we're on track?"*
- *"How will we address things if we find we're off track?"*
- *"How does this affect the rest of your team?"*
- *"How on board are the people not on this call?"*
- *"What do your colleagues see as their main challenges in this area?"*

---

## What to Avoid

- **Never push for "Yes" early** — it triggers defensiveness; the counterpart feels manipulated
- **Never say "I'm hearing that..."** — the word "I" signals you're more interested in yourself
- **Never split the difference** — compromise produces bad outcomes for both; "no deal is better than a bad deal"
- **Never use the Assertive voice as default** — dominance triggers push-back (active or passive)
- **Never treat "You're right" as a win** — it means they want you to stop talking; nothing changes
- **Never treat "I'll try" as a commitment** — it means "I plan to fail"
- **Never project your negotiator type onto the counterpart** — 66% chance they're different from you
- **Never make assumptions** — treat them as hypotheses; stay in discovery mode
- **Never go too fast** — people who feel rushed feel unheard; rapport breaks down
- **Never shove negative leverage down their throat** — label it subtly instead
- **Never use round numbers in a final offer** — they feel like placeholders and invite counters
- **Never ignore the people not at the table** — they often control the real decision
- **Never fake anger** — strategic umbrage must be genuine or it backfires
- **Never say "Why"** except when the defensiveness serves you

---

## Quick Reference Card

| Situation | Tool | Script |
|-----------|------|--------|
| They're talking, keep them going | Mirror | [Repeat last 1–3 words] + silence |
| Sense an emotion | Label | *"It seems like..."* + silence |
| Need to say No | Calibrated Q | *"How am I supposed to do that?"* |
| They say "you're right" or "I'll try" | Dive back in | More "How" questions |
| Ignored via email | No-trigger | *"Have you given up on this project?"* |
| Starting a hard conversation | Accusation Audit | Say their worst fears first |
| Price negotiation | Ackerman | 65% → 85% → 95% → 100% with non-round final |
| Need commitment that sticks | Rule of Three | Get same agreement 3x in one conversation |
| Deadlock | Pivot | *"What would make this work for both of us?"* |
| Want to seem human | Name | *"My name is Chris. What's the Chris discount?"* |

---

## Changelog
- 2026-03-22: Initial SOP created from *Never Split the Difference* by Chris Voss
