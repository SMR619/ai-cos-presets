# SOP: Content Analysis Framework
**Version:** 2.0
**Last Updated:** 2026-04-27
**Applies to:** All AI CoS agents — videos, articles, podcasts, courses, webinars

---

## Purpose

When the principal says "analyze this," "review this," "check this out," or shares a YouTube URL or article link — this SOP defines exactly what that means. The goal is **actionable intelligence and business application**, not summarization.

---

## Step 1 — Always Pull the Full Source

- **YouTube** → Supadata API first, always. Never web_fetch on YouTube URLs (VPS IPs are blocked).
- **Articles/web** → web_fetch or Firecrawl
- **Never analyze from memory, partial info, or the title alone** — get the real content
- **If transcript pull fails:** Say so explicitly ("Could not pull transcript for [URL]") — never proceed as if analysis was done

---

## Step 2 — Evaluate Through ALL THREE Lenses (Never Skip Any)

| Lens | Question |
|------|----------|
| 🏗️ Current businesses | Does this improve, affect, or create risk for any active business? |
| 📋 Active projects | Does this accelerate, change, conflict with, or unlock work in flight? |
| 💰 New opportunity | Is this a revenue stream worth pursuing — automated, scalable, low overhead? |

**Critical:** Never dismiss content as "not relevant" without checking all three lenses. Something that doesn't apply to current work may still be a new opportunity. Automated or mostly passive income streams are always worth flagging.

---

## Step 3 — Cross-Reference for Hidden Value

- Look for connections across businesses, projects, tools, and past discussions
- A single insight may have applications across multiple active initiatives
- Flag any connection explicitly, even if it seems tangential

---

## Step 4 — Depth Standard (Mandatory)

For every insight worth flagging, explain:
- **HOW it actually works** mechanically — not just what it does
- **HOW the principal would implement it** — specific steps, tools, connections, estimated cost
- **WHAT it looks like in practice** for their specific businesses
- **WHERE the catch is** — what breaks, what costs money, what requires ongoing maintenance

If you cannot explain the *how*, do not surface the insight. Bullets like "AI can automate X" or "this could help your business" are not analysis — they are titles.

Write like a business partner working through this in conversation — direct, specific, implementation-focused. Not a report.

## Step 5 — What "Analyze This" Does NOT Mean

- Summarize what was said (Cliff Notes, book report, chapter summary)
- Regurgitate the transcript with bullet points
- Surface insights the principal could've gotten from the title alone
- Generic takeaways with no implementation detail
- "This could help [business]" without explaining how, at what cost, and what setup looks like

---

## Output Format

Structure every analysis as:

```
# [Title / Creator / Date]

## Verdict
[Act on / Monitor / Skip — one sentence max]

## Source Credibility
[Who is this person? Skin in the game? Proven results or theoretical? 1-2 lines.]

## Key Insights & Nuggets
[Bullet list — principal-specific lens only. No filler. Ranked by relevance.]

## Recommended Actions
[Concrete next steps. If none, say none explicitly.]

## Business Impact
[Which business(es)? How specifically? Map it.]

## Tool / Solutions Relevance
[Does this affect, replace, or improve anything currently in use?]

## Project Connections
[Any active projects this touches? Be specific.]

## New Revenue Opportunity?
[Yes / No / Maybe]
[If yes or maybe: Is it automatable? Low overhead? Fits principal's profile? Rough effort-to-revenue ratio?]

## Watch Out For
[Risks, hype, caveats, red flags, things to be skeptical of]
```

---

## For Batches of Videos/Articles

When analyzing multiple pieces of content at once:
1. Lead with a **one-line verdict per item** so the principal can triage quickly
2. Then provide full breakdowns below, in the same order
3. If themes emerge across the batch, add a **Cross-Batch Synthesis** section at the end

---

## Adapting to New Businesses / Projects

As the principal adds new businesses or projects, the three-lens evaluation expands automatically. Any new active project becomes a filter through which all future content is evaluated.

---

## Filing

- Save substantive analyses to the relevant SOP, project, or knowledge folder
- If part of a larger body of work from one creator, accumulate findings before writing a synthesis
- Flag anything that should be added to an existing playbook or preset

---

*This SOP is a standard part of every AI CoS agent setup. Every agent that analyzes content for a principal should operate from this framework.*
