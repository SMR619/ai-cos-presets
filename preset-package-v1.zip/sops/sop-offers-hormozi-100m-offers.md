# SOP: $100M Offers — Creating Grand Slam Offers
**Source:** $100M Offers by Alex Hormozi  
**Processed:** 2026-03-23  
**Applies To:** [BUSINESS NAME] (adapt examples to your specific industry and offers)

---

## CORE FRAMEWORK SUMMARY

A **Grand Slam Offer** is an offer so good that your prospect cannot compare it to anything else in the market — you sell in a "category of one." The purchasing decision becomes between your offer and nothing, not between you and a competitor.

The three impacts of a Grand Slam Offer:
1. **Increased Response Rates** — more people click/respond to ads
2. **Increased Conversion** — more people who respond actually buy
3. **Premium Pricing** — ability to charge significantly more

**The Core Math:** New Clients/Month × Lifetime Value = Max Revenue/Month

**22.4x Revenue Example:**  
- Commodity offer: $10k ad spend → 5 sales at $1,000 = $5,000 (ROAS 0.5:1)  
- Grand Slam offer: $10k ad spend → 28 sales at $3,997 = $112,000 (ROAS 11.2:1)  
- Multiplier: 2.5x response × 2.5x conversion × 4x price = **22.4x more cash**

---

## KEY PRINCIPLES

1. **Market > Offer > Persuasion.** A starving crowd + bad offer > great offer + wrong market. Pick the right market first.

2. **Niche to get rich.** The same core product charges 100x more when niched. Below $10M/yr: niche down hard. Example: "Time Management" = $19; "Time Management for B2B Outbound Power Tools Sales Reps" = $1,997.

3. **Raise price, raise results.** Higher price → higher emotional investment → higher client results → better referrals → more margin for reinvestment. Lower price does the opposite.

4. **Focus on the bottom of the Value Equation.** Beginners increase claims (top). Winners reduce time delay and effort (bottom). If you make time delay and effort/sacrifice = zero, value approaches infinity.

5. **Solve every problem.** A single unresolved objection can kill the sale. Identify 30–60+ problems and solve all of them.

6. **Stack, don't discount.** Adding bonuses is always superior to discounting. Discounting trains customers that prices are negotiable.

7. **Scarcity + Urgency + Bonuses + Guarantees + Naming.** These are the five enhancers that multiply the core offer.

8. **The Virtuous Cycle of Price:** Higher price → better clients → better results → better testimonials → higher prices.

---

## THE VALUE EQUATION

```
Value = (Dream Outcome × Perceived Likelihood of Achievement)
        ÷ (Time Delay × Effort & Sacrifice)
```

**Four levers:**

| Driver | Direction | How to Move It |
|--------|-----------|----------------|
| Dream Outcome | ↑ Increase | Frame benefits as status gains; connect to what others will think of them |
| Perceived Likelihood | ↑ Increase | Testimonials, case studies, guarantees, specificity of claims |
| Time Delay | ↓ Decrease | Fast wins early; short-term results + long-term outcome |
| Effort & Sacrifice | ↓ Decrease | Done-for-you > done-with-you > DIY |

**Pro Tip — Fast Beats Free:** The only thing that beats "free" is "fast." People will pay for speed. Price accordingly.

**Pro Tip — Status:** The dream outcome that most directly increases a prospect's STATUS in the eyes of others is the one they'll pay the most for.

---

## THE 5-STEP GRAND SLAM OFFER CREATION PROCESS

### Step 1: Identify Dream Outcome
Define what the prospect actually wants — not the vehicle (membership), but the destination (lose 20 lbs in 6 weeks without giving up wine). Be specific. Include timeframe.

### Step 2: List All Problems/Obstacles
Write down every obstacle, limiting belief, and struggle prospects face. Map each to the four value drivers:
- **Dream Outcome objection:** "This will not be financially worth it"
- **Likelihood objection:** "It won't work for me specifically. I won't stick with it."
- **Effort objection:** "This will be too hard, confusing. I will suck at it."
- **Time objection:** "This will take too much time. I'm too busy."

**Goal:** Generate 16+ core problems with 2–4 sub-problems each = 32–64 total problems.

**Think in sequence:** What happens immediately BEFORE and AFTER someone uses your product/service?

### Step 3: Create Solutions List
Transform every problem into a solution using this formula:
- "How to [reverse the problem] so that [benefit], even if [common objection]"

**Examples:**
- "Buying healthy food is hard" → "How to make buying healthy food easy and enjoyable, so anyone can do it"
- "Can't do it while traveling" → "How to get healthy food when traveling for work"

**Rule: You MUST solve EVERY problem.** One unsolved obstacle can prevent a sale.

### Step 4: Create Solution Delivery Vehicles

**The Delivery Cube — Six Dimensions:**
1. **Level of personal attention:** One-on-one, small group, one-to-many
2. **Level of effort from client:** DIY, Done-With-You (DWY), Done-For-You (DFY)
3. **Live delivery medium:** In-person, phone, email, text, Zoom, chat
4. **Recording format:** Audio, video, written
5. **Response speed/availability:** 24/7, 9–5, within 5 min, within 1 hr, within 24 hrs
6. **10x / 1/10th test:**
   - If clients paid 10x your price, what would you provide?
   - If they paid 1/10th and you had to make it more valuable, how?

Use divergent thinking — write down everything possible, even if impractical.

### Step 5: Trim & Stack

**Remove in this order:**
1. High cost, low value items (first)
2. Low cost, low value items (second)

**Keep:**
- Low cost, HIGH value (especially one-to-many solutions — record once, deliver infinitely)
- High cost, HIGH value (anchor items, premium tiers)

**Format each bundle item as:**
`[Problem] → [Solution] → [Sexy Name] ($$$$ value)`

**Stack presentation:** Anchor price to core offer → add bonuses sequentially → watch price-to-value gap grow → until it "snaps" and they buy.

---

## MARKET SELECTION FRAMEWORK

**Four Indicators of a Good Market:**
1. **Massive Pain** — Degree of pain is proportional to price you can charge. "The pain is the pitch."
2. **Purchasing Power** — They can afford what you need to charge.
3. **Easy to Target** — They gather somewhere (associations, Facebook groups, LinkedIn, trade publications).
4. **Growing** — Tailwind market vs. headwind.

**The Three Evergreen Markets** (always massive pain + purchasing power):
- Health
- Wealth
- Relationships

---

## PRICING STRATEGY

**Never be the second cheapest.** There is no strategic benefit to it. The most expensive provider in the market has a clear advantage — uniqueness is implied by price alone.

**The Standard Bad Pricing Process (avoid):**
1. Look at what competitors charge
2. Take the average
3. Go slightly below to be "competitive"
4. End up broke competing on price

**The Grand Slam Pricing Process:**
1. Build enormous value (100x the price in perceived value)
2. Price at a significant premium to commodity alternatives
3. Let the price communicate quality and exclusivity

**Wine Study:** Same wine, three "prices." Tasters rated the "expensive" wine best. Same wine. Same glass. Price = perceived quality. This is not manipulation — it's psychology you must use.

---

## SCARCITY TACTICS

**Definition:** Fixed supply or quantity — creates fear of missing out (FOMO). Fear of loss > desire for gain.

**Three Types:**
1. Limited supply of seats/slots
2. Limited supply of bonuses
3. "Never available again"

**For Services:**
- **Total Business Cap:** "Only accepting X clients at this service level." Create waitlist. Grow 10–20% then cap.
- **Growth Rate Cap:** "Only accepting 5 new clients per week. 3 spots already taken."
- **Cohort Cap:** "Only accepting X clients per cohort." Start monthly or quarterly.
- **"Once You're Out, You Can Never Come Back":** Cap service and state it. Powerful with small groups.
- **Extreme Scarcity:** Cap 1-on-1 access (DM, phone, Zoom) at tiny number. Price very high. Tell people.

**Honest Scarcity (Most Ethical):** Define how many clients you can handle in a given period and advertise that number. Being 81% to capacity implies social proof and accelerating scarcity.

---

## URGENCY TACTICS

**Definition:** Scarcity = quantity constraint; Urgency = time constraint. Limit WHEN people can sign up.

**Four Methods:**

1. **Cohort-Based Rolling Urgency:**
   "If you sign up today, I can get you into our next group starting Monday. Otherwise you'll wait for our next cohort."
   *Enhanced: "A client just dropped out. If you're going to do this sooner or later, might as well get in now."*

2. **Rolling Seasonal Urgency:**
   Name promotions by season — "New Year Promotion ends Jan 30!" The promotion can be identical; the name/deadline creates real urgency.
   - Jan: New Year New You
   - Feb: Valentine's Offer
   - Mar: Sexy by Spring
   - Q4: Holiday Transformation
   **Deadlines drive decisions.** 50–60% of weekly campaign sales happen in the last 4 hours of the last day.

3. **Pricing/Bonus-Based Urgency:**
   "Let's get you started today so you can lock in this discount. I'm not sure how long we'll be running it."
   *Pro Tip: Never raise prices without warning — alert pipeline first. "Cleaning your pipeline" = notifying leads before price increase.*

4. **Exploding Opportunity:**
   When market conditions, platform advantages, or arbitrage windows are time-limited. "Every day you wait, you miss disproportionate gains."

---

## BONUS FRAMEWORK

**Core Principle:** A single offer is less valuable than the same offer broken into its component parts and stacked as bonuses. This is why infomercials always say "but wait, there's more!"

**Presentation Rules (The 11 Bullets):**
1. Always offer bonuses
2. Give each a special name with a benefit in the title
3. For each bonus, tell them: (a) how it relates to their obstacle, (b) what it is, (c) how you discovered/created it, (d) how it improves their life
4. Provide proof (stat, client result, personal experience)
5. Paint a vivid mental image of life after using it
6. Always ascribe a price tag and justify it
7. **Tools & checklists > additional trainings** (lower effort = higher value per Value Equation)
8. Each bonus should address a specific concern about why they can't succeed
9. Solve their NEXT problem before they encounter it
10. Bonus value should eclipse the core offer value
11. Apply scarcity and urgency to bonuses themselves

**Advanced: Other People's Products as Bonuses**
- Negotiate with non-competing businesses: they provide products/services as your bonuses in exchange for exposure
- Also negotiate: (a) group discounts for your clients, (b) referral commissions for yourself
- Result: A $400 offer with $400+ in bonuses AND you earn $350 extra per client from referral fees

**1-on-1 Bonus Sequence:**
1. Ask for the sale FIRST, before offering bonuses
2. If YES → reveal bonuses after signup (reinforces decision)
3. If NO → present a bonus addressing their objection → ask again
4. Continue layering bonuses one at a time (triggers reciprocity)

---

## GUARANTEE FRAMEWORK

**Core Principle:** Risk is the single greatest objection to any offer. Reversing risk immediately makes offers more attractive.

**The Math:** If guarantees increase closes 30% and double refund rate (5% → 10%):
- Without: 100 sales × 95% kept = 95 net
- With: 130 sales × 90% kept = 117 net
- **23% net increase** — almost always worth it

### Type 1: Unconditional Guarantee
Customer pays, then decides if they want it. No conditions.
- Full refund, no questions asked
- Satisfaction-based: "If at any time you're not satisfied, request a refund"
- Money back + competitor's program paid for
- Money back + additional $1,000

**Best for:** Lower-ticket B2C. High-volume offers. Works when fulfillment cost is low.

### Type 2: Conditional Guarantee
"Better than money back" — conditions protect you while creating accountability.
- **Outsized Refund:** Double or triple money back IF they complete specified actions. (Jason Fladlien offered to buy an ecommerce store for $25k if course didn't work → +$3M sales with only 10 refunds)
- **Service Guarantee (Hormozi's Favorite):** Keep working for them for FREE until result is achieved. Never at risk of losing money. In practice, almost no one takes you up on it.
- **Modified Service Guarantee:** Additional X months of service free at least 2x original duration
- **Credit Guarantee:** Credit applied toward any future service
- **Personal Service (DFY Guarantee):** 1-on-1 until they hit the objective
- **First Outcome Guarantee:** Continue paying ancillary costs (ads, hotel) until first milestone hit
- **Release Guarantee:** Let them out of contract free if unsatisfied

**How to design good conditions:**
1. Easy to track
2. Gets customers actual results (align with what best clients do naturally)
3. Conditions that also market the business (posts, tags, referrals)

### Type 3: Anti-Guarantee
"All sales are final." Works when product is so proprietary it can be "stolen" once seen.
- Position with creative framing: "We're sharing our live funnels, ads, and metrics. Once you see inside our operation, you have full access. That's why all sales are final."
- Or: "If you need a guarantee before starting, you're not the client we're looking for."

### Type 4: Implied Guarantee (Performance-Based)
If I don't perform, I don't get paid.
- Revenue share (% of top-line)
- Profit share (% of gross profit)
- Ratchets (10% if >$X, 20% if >$Y, 30% if >$Z)
- Pay-per-result: per show, per lead, per sale
- Combine with minimum: "Greater of $1,000 or 10% of revenue generated"

**Best for:** Media buying ([BUSINESS NAME]), performance marketing, any results-based service.

**Stacking Guarantees:** Combine unconditional 30-day + conditional 90-day = future-paces prospect through multiple outcome milestones.

**Naming Guarantees:** Replace generic names with vivid imagery:
- "30 Day Money Back" → "[Outcome]-Guaranteed or Your Money Back"
- Make the name memorable and specific to the result

---

## THE MAGIC NAMING FORMULA

**M-A-G-I-C** (use 3–5 components; order flexible; shorter is better)

| Letter | Component | Purpose | Examples |
|--------|-----------|---------|---------|
| M | **Magnet** — Reason Why | Why this offer exists now | Free, 88% off, Grand Opening, New Year, Summer, Anniversary |
| A | **Avatar** — Call out ideal client | Who is this for exactly | Bee Cave Dentists, Rolling Hills Moms, Salon Owners, Retired Athletes |
| G | **Goal** — Dream outcome | What they'll achieve | Pain Free, Celebrity Smile, Double Your Profit, First Client, 7-Figure |
| I | **Interval** — Time duration | How long it takes | 21-Day, 6-Week, 3-Month, 90-Day |
| C | **Container** — Bundle label | Signals it's a system | Challenge, Blueprint, Intensive, Masterclass, Accelerator, Sprint, System |

**Rhyming examples:** Six-Pack Fast Track, 5-Day Book Print Sprint, 12-Week 2-Putt Shortcut  
**Alliteration examples:** Make Money Masterclass, Change Your Life Challenge, Big Booty Bootcamp

**When offers fatigue, change in this order (lightest → heaviest):**
1. Change creative (images/photos)
2. Change body copy
3. Change headline/wrapper ("6 Week Lean" → "6 Week Tone")
4. Change seasonality
5. Change duration
6. Change enhancer (free vs. discount)
7. Change monetization structure (last resort — rarely change this once it works)

---

## PRACTICAL APPLICATION TO YOUR BUSINESSES

### [BUSINESS NAME] (Service / Media Buying Example)
**Grand Slam Offer Framework:**
- **Commodity offer:** "We provide [service] for your [client type]"
- **Grand Slam offer:** "We guarantee [specific outcome] or we keep working for free. We [unique mechanism], so your budget goes 2–4x further. Here's our full [plan/strategy/dashboard]. You only pay when we deliver."
- **Implied Guarantee:** Performance-based delivery — % of results generated or flat outcome guarantee
- **Anti-Guarantee angle:** "We're showing you our exact strategy, real-time data, and live dashboards. Once you see inside, you have the playbook. That's why we require commitment before we open the hood."
- **MAGIC Name:** "[Avatar] [Outcome] Accelerator" or "90-Day [Metric] Guarantee Program"
- **Scarcity:** "We only work with one [client type] per [territory/niche] at a time"

### [BUSINESS NAME] (Real Estate / Motivated Seller Example)
**Grand Slam Offer Framework (for motivated sellers):**
- **Dream Outcome:** "Keep your credit intact, avoid foreclosure, get a fair offer, close in X days"
- **Effort reduction:** "We handle all paperwork, pay all closing costs, work around your timeline"
- **Guarantee:** "If we can't close, we pay you [AMOUNT] for your time"
- **MAGIC Name:** "30-Day No-Hassle Home Relief Program" or "Stress-Free Sale in 14 Days"

**Grand Slam Offer (for wholesale buyers/JV partners):**
- Dream Outcome: "Below-market deals with creative financing that cash flow from day one"
- Guarantee: "If the numbers don't work as presented, full refund on assignment fee"

### [BUSINESS NAME] (Home Services / Installation Example)
**Grand Slam Offer Framework:**
- **Dream Outcome:** "Never [experience the problem] again."
- **Fast Win:** Free home assessment + report showing current vulnerability or gap
- **Stack:** Installation + monitoring app + annual maintenance check + priority service line + warranty
- **Guarantee:** "[Specific performance outcome] or we fix it free"
- **MAGIC Name:** "[Outcome] Protection System" or "[Result] Certainty Package"
- **Scarcity:** "Scheduling [X] weeks out — lock in your spot before [season/event]"

---

## QUICK REFERENCE CHECKLIST

**When building a new offer:**
- [ ] Identified specific dream outcome (not the vehicle, the destination)
- [ ] Listed 30+ problems/obstacles with sub-categories
- [ ] Every problem has a corresponding solution
- [ ] Solutions mapped to Delivery Cube (1-on-1, DWY, DFY formats)
- [ ] Trimmed to low-cost/high-value + high-cost/high-value items
- [ ] Each stack item has a sexy name + dollar value assigned
- [ ] Scarcity mechanism in place (supply limited)
- [ ] Urgency mechanism in place (time limited)
- [ ] 3+ bonuses that each address a specific objection
- [ ] Guarantee in place (type matches offer tier)
- [ ] Offer has MAGIC-formula name
- [ ] Price is premium (never second cheapest)
- [ ] Offer can be explained as: "I help [Avatar] get [Dream Outcome] in [Timeframe] without [Effort/Sacrifice] or [Risk — Guarantee]"
