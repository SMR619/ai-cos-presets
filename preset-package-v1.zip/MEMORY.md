# MEMORY.md — AI Chief of Staff Long-Term Memory

**Architecture:** Tier 1 — always loaded. Keep under 150 lines. Deep context lives in `wiki/*.md`, project `STATUS.md` files, and daily session notes.
**Wiki location:** `/data/syncthing-workspace/wiki/` (domain files — read on demand)

---

## 🔑 Session Startup
1. Read `SOUL.md`
2. Read most recent file in `/data/.openclaw/workspace/memory/` for full recent context
3. Check `open-items.md` for outstanding items
4. Read relevant wiki domain file before discussing any specific project, deal, or person

---

## 🔴 Active Flags
*(None yet — will be populated as we work together)*

---

## 🏗️ Key Infrastructure
*(Fill in after setup)*

- Gateway watchdog cron ID: [FILL IN]
- Syncthing watchdog cron ID: [FILL IN]
- Key scripts location: [FILL IN]
- Restore kit: `/data/syncthing-workspace/ava-recovery/AVA_RESTORE_KIT.md` *(create during onboarding)*
- Tasks (one-offs): `/data/syncthing-workspace/tasks.md`
- Builds (multi-step projects): `/data/syncthing-workspace/builds.md`
- Open items: `/data/syncthing-workspace/open-items.md`

---

## 🎯 Business Priority Stack
*(Fill in during onboarding — what are the top businesses or revenue streams?)*

1. [FILL IN]
2. [FILL IN]
3. [FILL IN]

---

## 📧 Email Configuration
*(Fill in after email setup)*

- Business email(s): [FILL IN]
- Provider: [Microsoft 365 / Google Workspace / Gmail / Other]
- Auth method: [Graph API / OAuth / App Password / SMTP]
- Status: [pending setup]
- Notes: [any caveats]

---

## 💡 Working Preferences
*(Fill in during onboarding — how the owner likes to work)*

- **Ease and scale over price** — always the paid/automated solution when the math works
- **"Handle it"** = full autonomy to decide and execute
- **"Save checkpoint"** = update all memory files, confirm back *(or update with owner's chosen code phrase)*

---

## 🔧 Model Routing (see AGENTS.md for full table)
- **Fast/cheap (Haiku)** → heartbeats, cron checks, simple lookups, templated sends
- **Standard (Sonnet)** → default for all active work
- **Deep analysis (Opus)** → deep strategic analysis only, under 20% usage

Current model assignments: [FILL IN — check AGENTS.md and OpenClaw settings]

---

## 🔍 Solutions Playbook
Before recommending any tool: check `/data/syncthing-workspace/solutions-playbook/tools-master-database.md`
Before recommending any process: check `/data/syncthing-workspace/solutions-playbook/PLAYBOOK.md`

---

## 📅 Session History (detail in daily files)
*(Log each session here as a one-liner after it happens)*

- [YYYY-MM-DD] — [brief description] — See `memory/[YYYY-MM-DD].md`
